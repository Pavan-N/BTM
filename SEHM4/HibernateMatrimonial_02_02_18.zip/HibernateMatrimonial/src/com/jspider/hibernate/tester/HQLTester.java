package com.jspider.hibernate.tester;

import com.jspider.hibernate.dao.MatrimonyDAO;
import com.jspider.hibernate.dto.MatrimonyDTO;

public class HQLTester 
{

	public static void main(String[] args)
	{
		/*MatrimonyDTO dto = new MatrimonyDTO();
		
		dto.setAge(28);
		dto.setName("Katappa");
		dto.setQualification("Tenth");*/
		MatrimonyDAO matrimonyDAO = new MatrimonyDAO();
		//matrimonyDAO.savePerson(dto);
		
		System.out.println("Person Name: " + matrimonyDAO.getPersonName(1));
	}

}

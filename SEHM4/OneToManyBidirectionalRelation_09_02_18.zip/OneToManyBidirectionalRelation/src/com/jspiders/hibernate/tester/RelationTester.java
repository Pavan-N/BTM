package com.jspiders.hibernate.tester;

import java.util.ArrayList;
import java.util.List;

import com.jspiders.hibernate.dao.TreeDAO;
import com.jspiders.hibernate.dto.FruitDTO;
import com.jspiders.hibernate.dto.TreeDTO;

public class RelationTester {

	public static void main(String[] args) {
		TreeDTO treeDTO = new TreeDTO();
		treeDTO.setName("MangoTree");
		treeDTO.setYears(25);
		treeDTO.setHeight(6.89);
		
		FruitDTO fruitDTO = new FruitDTO();
		fruitDTO.setColour("Green");
		fruitDTO.setWeight(100.7);
		fruitDTO.setTree(treeDTO);
		
		FruitDTO fruitDTO2 = new FruitDTO();
		fruitDTO2.setColour("Yellow");
		fruitDTO2.setWeight(87.89);
		
		
		
		FruitDTO fruitDTO3 = new FruitDTO();
		fruitDTO3.setColour("Green");
		fruitDTO3.setWeight(137.7);
		
		
		List<FruitDTO> listOfFruit = new ArrayList<FruitDTO>();
		listOfFruit.add(fruitDTO);
		listOfFruit.add(fruitDTO2);
		listOfFruit.add(fruitDTO3);
		
		fruitDTO.setTree(treeDTO);
		fruitDTO2.setTree(treeDTO);
		fruitDTO3.setTree(treeDTO);
		treeDTO.setFruit(listOfFruit);
		
		TreeDAO treeDAO = new TreeDAO();
		treeDAO.saveTree(treeDTO);
		
	}

}

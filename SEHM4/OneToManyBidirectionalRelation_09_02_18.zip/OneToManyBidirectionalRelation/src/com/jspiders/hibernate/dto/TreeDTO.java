package com.jspiders.hibernate.dto;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "tree_table")
public class TreeDTO implements Serializable {
	@Id
	@GenericGenerator(name = "auto", strategy = "increment")
	@GeneratedValue(generator = "auto")
	@Column(name = "t_id")
	private int treeId;
	@Column(name = "t_name")
	private String name;
	@Column(name = "t_height")
	private double height;
	@Column(name = "t_years")
	private int years;

	@OneToMany(mappedBy = "tree", cascade = CascadeType.ALL)
	private List<FruitDTO> fruit;
	
	public int getTreeId() {
		return treeId;
	}

	public void setTreeId(int treeId) {
		this.treeId = treeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public int getYears() {
		return years;
	}

	public void setYears(int years) {
		this.years = years;
	}

	public List<FruitDTO> getFruit() {
		return fruit;
	}

	public void setFruit(List<FruitDTO> fruit) {
		this.fruit = fruit;
	}
	

}

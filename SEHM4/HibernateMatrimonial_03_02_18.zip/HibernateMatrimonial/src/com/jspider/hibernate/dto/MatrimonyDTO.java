package com.jspider.hibernate.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="matrimony_table")
public class MatrimonyDTO implements Serializable{
	@GenericGenerator(name="auto",strategy="increment")
	@GeneratedValue(generator="auto")
	@Id
	@Column(name="p_id")
	private int pId;
	@Column(name="p_age")
	private int age;
	@Column(name="p_name")
	private String name;
	@Column(name="p_qualification")
	private String qualification;
	
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}


}

package com.jspider.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.jpspiders.hibernate.util.HibernateUtil;
import com.jspider.hibernate.dto.MatrimonyDTO;

public class MatrimonyDAO {
	private SessionFactory factory = HibernateUtil.getSessionFactory();
	public Integer savePerson(MatrimonyDTO dto) {
		Session session = null;
		Transaction txn = null;
		try {
			session=factory.openSession();
			txn=session.beginTransaction();
			session.save(dto);
			txn.commit();
		}
		catch(HibernateException e) {
			e.printStackTrace();
			txn.rollback();
		}
		finally
		{
			if(session!=null)
			session.close();
		}
		return null;
	}
	
	
	public String getPersonNameById(int primaryKey) {
		Session session = null;
		String personName = null;
		String hql = "SELECT name FROM MatrimonyDTO WHERE pId="+primaryKey;
		try {
			session = factory.openSession();
			Query query = session.createQuery(hql);
			personName = (String) query.uniqueResult();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (session != null)
			session.close();
		}
		return personName;
		
	}
	

	public MatrimonyDTO getPersonById(String personName) {
		Session session = null;
		MatrimonyDTO person = null;
		try {
			String hql = "SELECT matrimony FROM "
					+ "MatrimonyDTO matrimony WHERE matrimony.name=:nm";
			session = factory.openSession();
			Query query = session.createQuery(hql);
			query.setParameter("nm", "Katappa");
			person = (MatrimonyDTO) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null)
			session.close();
		}
		return person;
	}
	
	
	public int updatePersonNameByQualification(String personName, String qualification) {
		Session session = null;
		Transaction tx = null;
		int noOfRowsAffected = 0;
		try {
			String hql = "UPDATE MatrimonyDTO matrimony SET matrimony.name=:nm "
					+ "WHERE matrimony.qualification=:ql";
			session = factory.openSession();
			tx = session.beginTransaction();
			Query query = session.createQuery(hql);
			query.setParameter("nm", personName);
			query.setParameter("ql", qualification);
			noOfRowsAffected = query.executeUpdate();
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			if (session != null)
			session.close();
		}
		return noOfRowsAffected;
		
	}
}

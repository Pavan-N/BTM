package com.jspider.hibernate.tester;

import com.jspider.hibernate.dao.MatrimonyDAO;
import com.jspider.hibernate.dto.MatrimonyDTO;

public class HQLTester 
{

	public static void main(String[] args)
	{
/*		MatrimonyDTO dto = new MatrimonyDTO();
		
		dto.setAge(28);
		dto.setName("Katappa");
		dto.setQualification("Tenth");
		
		//matrimonyDAO.savePerson(dto);
*/		
		
		MatrimonyDAO matrimonyDAO = new MatrimonyDAO();
		//System.out.println("Person Name: " + matrimonyDAO.getPersonNameById(1));
		
		/*MatrimonyDTO matrimonyDTO = matrimonyDAO.getPersonById("Katappa");
		System.out.println(matrimonyDTO.getAge() + "\t" + matrimonyDTO.getQualification());*/
		
		int rowsAffected = matrimonyDAO.updatePersonNameByQualification("Bahubali", "Tenth");
		System.out.println("Rows Affected: " + rowsAffected);
		
		
		
		
		
		
		
		
		
		
		
	}

}

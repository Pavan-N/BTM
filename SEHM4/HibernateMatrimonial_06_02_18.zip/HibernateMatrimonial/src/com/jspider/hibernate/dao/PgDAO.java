package com.jspider.hibernate.dao;

import java.util.LinkedList;
import java.util.List;

import com.jspider.hibernate.dto.PgDTO;

public class PgDAO {

	public Integer savePG(PgDTO dto) {
		//impl
		return null;
	}
	
	public void saveAllPgs(LinkedList<PgDTO> pgList) {
		//impl
	}
	
	public List<PgDTO> getPgByType(String type){
		return null;
	}
	
	public PgDTO getPgById(int primaryKey) {
		//impl
		return null;
	}
	
	public int updatePgRentByName(String name, double rent) {
		//impl
		return 0;
	}
	
	public void deletePgId(int primaryKey) {
		//impl
	}
	
	public Integer getPgCount() {
		//impl
		return null;
	}
	
	public PgDTO getPgByName(String PgName) {
		//impl
		return null;
	}
}

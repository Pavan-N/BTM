package com.jspider.hibernate.tester;

import java.util.List;

import com.jspider.hibernate.dao.MatrimonyDAO;
import com.jspider.hibernate.dto.MatrimonyDTO;

public class HQLTester 
{

	public static void main(String[] args)
	{
		MatrimonyDTO dto = new MatrimonyDTO();
		MatrimonyDAO matrimonyDAO = new MatrimonyDAO();
		
		/*dto.setAge(29);
		dto.setName("Ballala");
		dto.setQualification("Ph.D");
		
		matrimonyDAO.savePerson(dto);*/
		
		
		
		//System.out.println("Person Name: " + matrimonyDAO.getPersonNameById(1));
		
		/*MatrimonyDTO matrimonyDTO = matrimonyDAO.getPersonById("Katappa");
		System.out.println(matrimonyDTO.getAge() + "\t" + matrimonyDTO.getQualification());*/
		
		/*int rowsAffected = matrimonyDAO.updatePersonNameByQualification("Bahubali", "Tenth");
		System.out.println("Rows Affected: " + rowsAffected);*/
		/*
		Object[] nameAndAge = matrimonyDAO.getPersonNameAndAgeById(1);
		System.out.println("Person name: " + nameAndAge[0]);
		System.out.println("Person age: " + nameAndAge[1]);
		*/
		
		
		
		/*List<MatrimonyDTO> persons = matrimonyDAO.fetchAllPersons();
		
		for (MatrimonyDTO matrimonyDTO : persons) {
			System.out.println(matrimonyDTO.getName() + "\t" + matrimonyDTO.getQualification());
		}*/
		
		/*List<Object[]> personNameAndQualification = matrimonyDAO.fetchPersonNameAndQualificationByAge(27);
		
		for (Object[] nameAndQualification : personNameAndQualification) {
			System.out.println("Name: " + nameAndQualification[0]);
			System.out.println("Qualification: " + nameAndQualification[1]);
		}*/
		
		//System.out.println("Max Age: " + matrimonyDAO.getMaxAge());
		
		System.out.println("Rows updated: " + matrimonyDAO.updatePersonQualificationByName("Bahubali", "Ph.D"));
	}

}

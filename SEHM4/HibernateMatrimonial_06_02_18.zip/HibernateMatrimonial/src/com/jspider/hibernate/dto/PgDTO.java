package com.jspider.hibernate.dto;

public class PgDTO {

}

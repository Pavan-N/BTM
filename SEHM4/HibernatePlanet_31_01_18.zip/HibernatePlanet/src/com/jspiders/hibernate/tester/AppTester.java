package com.jspiders.hibernate.tester;

import com.jspiders.hibernate.dao.PlanetDAO;
import com.jspiders.hibernate.dto.PlanetDTO;

public class AppTester {

	public static void main(String[] args) {
		PlanetDTO planetDTO = new PlanetDTO();
		
		PlanetDAO planetDAO = new PlanetDAO();
		
		planetDTO.setName("Pluto");
		planetDTO.setColour("white");
		planetDTO.setMass(234.12);

		Integer planetId = planetDAO.savePlanet(planetDTO);
		System.out.println("Planet saved with id: " + planetId);
		
		//PlanetDTO planetDTO = planetDAO.getPlanet(2);
		//System.out.println(planetDTO.getName());
		
		//planetDAO.updatePlanet(1, "Earth");
	}
	
	
	

}

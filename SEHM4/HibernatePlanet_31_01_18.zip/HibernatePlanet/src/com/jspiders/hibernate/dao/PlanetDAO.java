package com.jspiders.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.jpspiders.hibernate.util.HibernateUtil;
import com.jspiders.hibernate.dto.PlanetDTO;

public class PlanetDAO {

	private SessionFactory factory = HibernateUtil.getSessionFactory();
	
	public Integer savePlanet(PlanetDTO dto) {
		Transaction tx =  null;
		Integer id = null;
		try(Session session = factory.openSession()) {
			tx = session.beginTransaction();
			id = (Integer) session.save(dto);
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			tx.rollback();
		}
		return id;
	}
	
	public PlanetDTO getPlanet(int primaryKey) {
		PlanetDTO dto = null;
		Session session = null;
		try {
			session = factory.openSession();
			dto = session.get(PlanetDTO.class, new Integer(primaryKey));
			System.out.println("using load method");
			dto.getName();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return dto;
	}
	
	public void updatePlanet(int primaryKey, String planetName) {
		Session session = null;
		Transaction tx = null;
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			PlanetDTO dto = session.load(PlanetDTO.class, new Integer(primaryKey));
			dto.setName(planetName);
			session.update(dto);
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			session.close();
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

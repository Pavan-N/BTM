package com.jspider.hibernate.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.jpspiders.hibernate.util.HibernateUtil;
import com.jspider.hibernate.dto.MatrimonyDTO;

public class MatrimonyDAO {
	private SessionFactory factory = HibernateUtil.getSessionFactory();
	public Integer savePerson(MatrimonyDTO dto) {
		Session session = null;
		Transaction txn = null;
		try {
			session=factory.openSession();
			txn=session.beginTransaction();
			session.saveOrUpdate(dto);
			txn.commit();
		}
		catch(HibernateException e) {
			e.printStackTrace();
			txn.rollback();
		}
		finally
		{
			if(session!=null)
			session.close();
		}
		return null;
	}
	
	
	public String getPersonNameById(int primaryKey) {
		Session session = null;
		String personName = null;
		String hql = "SELECT name FROM MatrimonyDTO WHERE pId="+primaryKey;
		try {
			session = factory.openSession();
			Query query = session.createQuery(hql);
			personName = (String) query.uniqueResult();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (session != null)
			session.close();
		}
		return personName;
		
	}
	
	
	public Object[] getPersonNameAndAgeById(int primaryKey) {
		Session session = null;
		Object[] personNameAndAge = null;
		String hql = "SELECT matrimony.name, matrimony.age FROM MatrimonyDTO matrimony "
				+ "WHERE matrimony.pId=:pk";
		try {
			session = factory.openSession();
			Query query = session.createQuery(hql);
			query.setParameter("pk", primaryKey);
			personNameAndAge =  (Object[]) query.uniqueResult();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (session != null)
			session.close();
		}
		return personNameAndAge;
	}

	public MatrimonyDTO getPersonById(String personName) {
		Session session = null;
		MatrimonyDTO person = null;
		try {
			String hql = "SELECT matrimony FROM "
					+ "MatrimonyDTO matrimony WHERE matrimony.name=:nm";
			session = factory.openSession();
			Query query = session.createQuery(hql);
			query.setParameter("nm", "Katappa");
			person = (MatrimonyDTO) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null)
			session.close();
		}
		return person;
	}
	
	
	public List<MatrimonyDTO> fetchAllPersons() {
		Session session = null;
		List<MatrimonyDTO> matrimonyDTO = null;
		String hql = "SELECT matrimony FROM MatrimonyDTO matrimony";
		try {
			session = factory.openSession();
			Query query = session.createQuery(hql);
			matrimonyDTO = query.list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null)
			session.close();
		}
		return matrimonyDTO;
	}
	
	
	public List<Object[]> fetchPersonNameAndQualificationByAge(int age) {
		Session session = null;
		List<Object[]> nameAndQualification = null;
		String hql = "SELECT matrimony.name, matrimony.qualification FROM MatrimonyDTO matrimony"
				+ " WHERE matrimony.age>:personAge";
		try {
			session = factory.openSession();
			Query query = session.createQuery(hql);
			query.setParameter("personAge", age);
			nameAndQualification = query.list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null)
			session.close();
		}
		return nameAndQualification;
	}
	
	public int updatePersonNameByQualification(String personName, String qualification) {
		Session session = null;
		Transaction tx = null;
		int noOfRowsAffected = 0;
		try {
			String hql = "UPDATE MatrimonyDTO matrimony SET matrimony.name=:nm "
					+ "WHERE matrimony.qualification=:ql";
			session = factory.openSession();
			tx = session.beginTransaction();
			Query query = session.createQuery(hql);
			query.setParameter("nm", personName);
			query.setParameter("ql", qualification);
			noOfRowsAffected = query.executeUpdate();
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			if (session != null)
			session.close();
		}
		return noOfRowsAffected;
	}
}

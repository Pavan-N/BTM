package com.jpsiders.hibernate.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.jpsiders.hibernate.dto.WeaponDTO;

public class WeaponDAO {

	public void saveWeapon(WeaponDTO dto) {
		//Component 1
		Configuration cfg = new Configuration();
		cfg.configure();
		
		//Component 2
		SessionFactory factory = cfg.buildSessionFactory();
		
		//Component 3
		Session session = factory.openSession();
		
		//Sub-Component 1 of session
		Transaction tx = session.beginTransaction();
		
		session.save(dto);
		tx.commit();
	}
}





package com.jpsiders.hibernate.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "weapon_table")
public class WeaponDTO implements Serializable {

	public WeaponDTO() {
		System.out.println("WeaponDTO Created");
	}

	@Id
	@Column(name = "w_id")
	private int id;
	@Column(name = "w_type")
	private String type;
	@Column(name = "w_weight")
	private double weight;
	@Column(name = "w_price")
	private double price;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "WeaponDTO [id=" + id + ", type=" + type + ", weight=" + weight + ", price=" + price + "]";
	}
	
}

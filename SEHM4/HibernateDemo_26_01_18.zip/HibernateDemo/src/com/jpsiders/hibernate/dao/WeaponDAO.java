package com.jpsiders.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.jpsiders.hibernate.dto.WeaponDTO;

public class WeaponDAO {

	public void saveWeapon(WeaponDTO dto) {
		// Component 1
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.xml");
		// Component 2
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = null;
		Transaction tx = null;
		
		// Component 3
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.save(dto);
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			session.close();
		}
		
		/*	
		try(Session session = factory.openSession()) {
			tx = session.beginTransaction();
			session.save(dto);
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			tx.rollback();
		} */

	}
	
	
	public WeaponDTO getWeapon(int primaryKey) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = null;
		try {
			session = factory.openSession();
			WeaponDTO dto = session.get(WeaponDTO.class, new Integer(primaryKey));
			return dto;
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		
		return null;
	}
}









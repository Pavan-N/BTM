package com.jpsiders.hibernate.tester;

import com.jpsiders.hibernate.dao.WeaponDAO;
import com.jpsiders.hibernate.dto.WeaponDTO;

public class AppTester {

	public static void main(String[] args) {
		/*WeaponDTO weaponDTO = new WeaponDTO();
		weaponDTO.setId(1);
		weaponDTO.setType("knife");
		weaponDTO.setPrice(20.5);
		weaponDTO.setWeight(50.90);
		
		System.out.println(weaponDTO);*/
		
		WeaponDAO dao = new WeaponDAO();
		//dao.saveWeapon(weaponDTO);
		
		WeaponDTO dtoFromDB = dao.getWeapon(1);
		System.out.println(dtoFromDB.getPrice() + "\t" + dtoFromDB.getType());
	}

	
	
	
}

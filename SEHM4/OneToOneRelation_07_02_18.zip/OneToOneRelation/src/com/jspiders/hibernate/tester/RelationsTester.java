package com.jspiders.hibernate.tester;

import com.jspiders.hibernate.dao.CaptainDAO;
import com.jspiders.hibernate.dto.CaptainDTO;
import com.jspiders.hibernate.dto.TeamDTO;

public class RelationsTester {

	public static void main(String[] args) {
		TeamDTO teamDTO = new TeamDTO();
		teamDTO.setTeamName("RCB");
		teamDTO.setNoOfPlayers(15);

		CaptainDTO captainDTO = new CaptainDTO();
		captainDTO.setName("VK");
		captainDTO.setExperience(8);
		
		captainDTO.setTeamDTO(teamDTO);
		
		CaptainDAO captainDAO = new CaptainDAO();
		captainDAO.saveCaptain(captainDTO);
		
	}

}

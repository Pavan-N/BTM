package com.jspiders.hibernate.dto;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "captain_table")
public class CaptainDTO implements Serializable {
	@Id
	@GenericGenerator(name = "jsp", strategy = "increment")
	@GeneratedValue(generator = "jsp")
	@Column(name = "captain_id")
	private int captainId;
	@Column(name = "name")
	private String name;
	@Column(name = "experience")
	private double experience;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "t_id")
	private TeamDTO teamDTO;

	public int getCaptainId() {
		return captainId;
	}

	public void setCaptainId(int captainId) {
		this.captainId = captainId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getExperience() {
		return experience;
	}

	public void setExperience(double experience) {
		this.experience = experience;
	}

	public TeamDTO getTeamDTO() {
		return teamDTO;
	}

	public void setTeamDTO(TeamDTO teamDTO) {
		this.teamDTO = teamDTO;
	}

}

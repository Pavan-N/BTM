package com.jspiders.hibernate.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "planet_table")
public class PlanetDTO implements Serializable {

	public PlanetDTO() {
		System.out.println(this.getClass().getSimpleName() + " created");
	}

	@Id
	@Column(name = "planet_id")
	private int planetId;
	@Column(name = "p_name")
	private String name;
	@Column(name = "p_colour")
	private String colour;
	@Column(name = "p_mass")
	private double mass;

	public int getPlanetId() {
		return planetId;
	}

	public void setPlanetId(int planetId) {
		this.planetId = planetId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public double getMass() {
		return mass;
	}

	public void setMass(double mass) {
		this.mass = mass;
	}

}

package com.jspiders.hibernate.tester;

import com.jspiders.hibernate.dao.PlanetDAO;
import com.jspiders.hibernate.dto.PlanetDTO;

public class AppTester {

	public static void main(String[] args) {
		//PlanetDTO planetDTO = new PlanetDTO();
		
		PlanetDAO planetDAO = new PlanetDAO();
		
		/*planetDTO.setPlanetId(1);
		planetDTO.setName("Earth");
		planetDTO.setColour("blue");
		planetDTO.setMass(1234.12);
*/
		/*Integer planetId = planetDAO.savePlanet(planetDTO);
		System.out.println("Planet saved with id: " + planetId);*/
		
		PlanetDTO planetDTO = planetDAO.getPlanet(2);
		//System.out.println(planetDTO.getName());
	}
	
	
	

}

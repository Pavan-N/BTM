package com.jspiders.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.jpspiders.hibernate.util.HibernateUtil;
import com.jspiders.hibernate.dto.TeamDTO;

public class TeamDAO {

private SessionFactory factory = HibernateUtil.getSessionFactory();
	
	public void saveTeam(TeamDTO teamDTO) {
		Session session = null;
		Transaction tx = null;
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.save(teamDTO);
			tx.commit();
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
	}
	
	public TeamDTO getTeamByName(String teamName) {
		Session session = null;
		TeamDTO dto = null;
		try {
			session = factory.openSession();
			Query query = session.getNamedQuery("fetchTeamByName");
			query.setParameter("name", teamName);
			dto = (TeamDTO) query.uniqueResult();
		} catch (HibernateException he) {
			// TODO Auto-generated catch block
			he.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
		return dto;
	}
}

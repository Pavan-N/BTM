package com.jspiders.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.jpspiders.hibernate.util.HibernateUtil;
import com.jspiders.hibernate.dto.CaptainDTO;

public class CaptainDAO {

	private SessionFactory factory = HibernateUtil.getSessionFactory();
	
	public void saveCaptain(CaptainDTO captainDTO) {
		Session session = null;
		Transaction tx = null;
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.save(captainDTO);
			tx.commit();
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
	}
}

package com.jspiders.hibernate.dto;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "team_table")
@NamedQueries({
	@NamedQuery(name = "fetchTeamByName", query = "SELECT team FROM TeamDTO team WHERE team.teamName=:name")
})
public class TeamDTO implements Serializable {
	@Id
	@GenericGenerator(name = "anything", strategy = "increment")
	@GeneratedValue(generator = "anything")
	@Column(name = "team_id")
	private int teamId;
	@Column(name = "t_name")
	private String teamName;
	@Column(name = "no_of_players")
	private int noOfPlayers;
	
	@OneToOne(mappedBy = "teamDTO", cascade = CascadeType.ALL)
	private CaptainDTO captain;

	public TeamDTO() {
		System.out.println(this.getClass().getSimpleName() + " created!!");
	}
	
	public int getTeamId() {
		return teamId;
	}

	public void setTeamId(int teamId) {
		this.teamId = teamId;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public int getNoOfPlayers() {
		return noOfPlayers;
	}

	public void setNoOfPlayers(int noOfPlayers) {
		this.noOfPlayers = noOfPlayers;
	}

	public CaptainDTO getCaptain() {
		return captain;
	}

	public void setCaptain(CaptainDTO captain) {
		this.captain = captain;
	}

}

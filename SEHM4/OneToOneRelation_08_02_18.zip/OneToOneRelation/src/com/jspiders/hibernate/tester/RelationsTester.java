package com.jspiders.hibernate.tester;

import com.jspiders.hibernate.dao.CaptainDAO;
import com.jspiders.hibernate.dao.TeamDAO;
import com.jspiders.hibernate.dto.CaptainDTO;
import com.jspiders.hibernate.dto.TeamDTO;

public class RelationsTester {

	public static void main(String[] args) {
		/*TeamDTO teamDTO = new TeamDTO();
		teamDTO.setTeamName("CSK");
		teamDTO.setNoOfPlayers(15);
		
		CaptainDTO captainDTO = new CaptainDTO();
		captainDTO.setName("MSD");
		captainDTO.setExperience(12);
		
		//bi-directional relationship
		captainDTO.setTeamDTO(teamDTO);
		teamDTO.setCaptain(captainDTO);*/
		
		/*CaptainDAO captainDAO = new CaptainDAO();
		captainDAO.saveCaptain(captainDTO);*/
		
		TeamDAO teamDAO = new TeamDAO();
		//teamDAO.saveTeam(teamDTO);
		
		TeamDTO team = teamDAO.getTeamByName("RCB");
		System.out.println("Team Id: " + team.getTeamId());
		CaptainDTO captain = team.getCaptain();
		System.out.println("Captain Name: " + captain.getName());
		//team.getCaptain().getName();
		
		
		
		
		
		
		
		
		
		
		
	}

}

package com.jspiders.spring.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.spring.bean.FoodBean;

public class AppTester {

	public static void main(String[] args) {
		ApplicationContext container = new ClassPathXmlApplicationContext("context.xml");
		
		FoodBean foodBean = container.getBean(FoodBean.class);
		System.out.println(foodBean.getName() + "\t" + foodBean.getPrice());
		System.out.println(foodBean.getType() + "\t" + foodBean.getQuantity());
	}

}

package com.jspiders.spring.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.spring.bean.SolarWaterHeaterBean;

public class AnnotationsTester {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
		
		SolarWaterHeaterBean waterHeaterBean = context.getBean(SolarWaterHeaterBean.class);
		System.out.println(waterHeaterBean.getCompany() + "\t" + waterHeaterBean.getPrice());
		waterHeaterBean.heatWater();
	}

}

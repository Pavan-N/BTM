package com.jspiders.spring.bean;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class SunBean implements Serializable {
	public SunBean() {
		System.out.println(this.getClass().getSimpleName() + " created..");
	}

	@Value(value = "20000")
	private double temperature;
	@Value(value = "VIBGYOR")
	private String colour;

	public double getTemperature() {
		return temperature;
	}

	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}
	
	public void provideHeatAndLight() {
		System.out.println("providing Heat And " + colour + " Light ");
	}

}

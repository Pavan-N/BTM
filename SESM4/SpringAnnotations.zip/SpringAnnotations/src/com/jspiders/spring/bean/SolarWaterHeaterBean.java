package com.jspiders.spring.bean;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
public class SolarWaterHeaterBean implements Serializable {

	public SolarWaterHeaterBean() {
		System.out.println(this.getClass().getSimpleName() + " created..");
	}
	
	
	public SolarWaterHeaterBean(@Value(value = "Bajaj") String company, @Value(value = "30.56") double capacity) {
		System.out.println(this.getClass().getSimpleName() + " created..");
		this.company = company;
		this.capacity = capacity;
	}
	
	@Autowired
	public SolarWaterHeaterBean(SunBean sun) {
		System.out.println(this.getClass().getSimpleName() + " created..");
		this.sun = sun;
	}

	private String company;
	private double capacity;
	private int price;
	private SunBean sun;

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		System.out.println("Setting company");
		this.company = company;
	}

	public double getCapacity() {
		return capacity;
	}

	public void setCapacity(double capacity) {
		System.out.println("Setting capacity");
		this.capacity = capacity;
	}

	public int getPrice() {
		return price;
	}

	@Value(value = "20")
	public void setPrice(int price) {
		System.out.println("Setting price");
		this.price = price;
	}

	public SunBean getSun() {
		return sun;
	}

	public void setSun(SunBean sun) {
		this.sun = sun;
	}
	
	public void heatWater() {
		sun.provideHeatAndLight();
		System.out.println("Heating the water..");
	}
}

package com.jspiders.ecommerce.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.jspiders.ecommerce.dto.RegisterDTO;
import com.jspiders.ecommerce.service.RegistrationService;

@Controller
@RequestMapping(value = "/")
public class RegistrationController {
	// RequestProcessing logic or Navigation logic

	@Autowired
	private RegistrationService service;

	@RequestMapping(value = "/reg.do")
	public ModelAndView register(@ModelAttribute RegisterDTO dto, HttpServletRequest req) {
		HttpSession session = req.getSession(true);
		session.setAttribute("username", dto.getUsername());
		System.out.println("Calling register method");
		boolean flag = service.registerUser(dto);

		if (flag) {
			return new ModelAndView("/success.jsp", "dto", dto);
		} else {
			return new ModelAndView("/error.jsp");
		}
	}
}

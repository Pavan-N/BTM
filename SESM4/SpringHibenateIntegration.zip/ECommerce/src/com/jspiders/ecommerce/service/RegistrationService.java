package com.jspiders.ecommerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jspiders.ecommerce.dao.RegistrationDAO;
import com.jspiders.ecommerce.dto.RegisterDTO;

@Service
public class RegistrationService {
//Business logic/ Validation logic
	
	@Autowired
	private RegistrationDAO dao;
	
	public boolean registerUser(RegisterDTO dto) {
		return dao.registerUser(dto);
	}
}

package com.jspiders.ecommerce.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jspiders.ecommerce.dto.RegisterDTO;

@Repository
public class RegistrationDAO {
//Persistence logic
	@Autowired
	private SessionFactory factory;
	
	public boolean registerUser(RegisterDTO dto) {
		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		try {
			session = factory.openSession();
			transaction = session.beginTransaction();
			session.save(dto);
			transaction.commit();
			flag = true;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return flag;
	}
}

package com.jspiders.spring.bean;

import java.io.Serializable;

public class CricketBean implements Serializable {
	private int noOfPlayers;
	private String type;
	private String name;
	private BatAndBall batBall;

	public CricketBean() {
		System.out.println(this.getClass().getSimpleName() + " creatd");
	}

	public CricketBean(BatAndBall batBall3) {
		this.batBall = batBall3;
		System.out.println(this.getClass().getSimpleName() + " creatd");
	}

	public int getNoOfPlayers() {
		return noOfPlayers;
	}

	public void setNoOfPlayers(int noOfPlayers) {
		this.noOfPlayers = noOfPlayers;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BatAndBall getBatBall() {
		return batBall;
	}

	public void setBatBall(BatAndBall batBall) {
		this.batBall = batBall;
	}

	public void play() {
//		System.out.println("Playing cricket");
		batBall.hit();
		System.out.println(name + " team Playing " + type +" cricket with " +
		 noOfPlayers);
	}
}

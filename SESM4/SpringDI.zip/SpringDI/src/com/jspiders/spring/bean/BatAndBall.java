package com.jspiders.spring.bean;

import java.io.Serializable;

public class BatAndBall implements Serializable {
	private String colour;
	private String brand;
	private double price;
	
	public BatAndBall() {
		System.out.println(this.getClass().getSimpleName() + " creatd");
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void hit() {
		System.out.println("Playing with " + brand + " of " + colour + " colour");
	}
}

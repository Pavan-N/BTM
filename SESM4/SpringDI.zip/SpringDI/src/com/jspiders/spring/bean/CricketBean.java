package com.jspiders.spring.bean;

import java.io.Serializable;

public class CricketBean implements Serializable {
	private int noOfPlayers;
	private String type;
	private String name;
	private BatAndBall batAndBall;

	public CricketBean() {
		System.out.println(this.getClass().getSimpleName() + " creatd");
	}
	
	public int getNoOfPlayers() {
		return noOfPlayers;
	}

	public void setNoOfPlayers(int noOfPlayers) {
		this.noOfPlayers = noOfPlayers;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BatAndBall getBatAndBall() {
		return batAndBall;
	}

	public void setBatAndBall(BatAndBall batAndBall) {
		this.batAndBall = batAndBall;
	}

	public void play() {
		System.out.println(name + " team Playing " + type +" cricket with " + noOfPlayers);
		batAndBall.hit();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

package com.jspiders.ecommerce.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.jspiders.ecommerce.dto.RegisterDTO;

@Component
@RequestMapping(value = "/")
public class RegistrationController {

	/*@RequestMapping(value= "/reg.do")
	public String register(HttpServletRequest req) {
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		String phoneNo = req.getParameter("phoneNumber");
		long phoneNumber = Long.parseLong(phoneNo);
		System.out.println("Calling register method");
		System.out.println(username + "\t" + password + "\t" + phoneNumber);
		return "/success.jsp";
	}*/
	
	/*@RequestMapping(value= "/reg.do")
	public String register(@RequestParam String username, @RequestParam String password, 
				@RequestParam long phoneNumber) {
		System.out.println("Calling register method");
		System.out.println(username + "\t" + password + "\t" + phoneNumber);
		return "/success.jsp";
	}*/
	
	/*@RequestMapping(value= "/reg.do")
	public ModelAndView register(@RequestParam String username, @RequestParam String password, 
				@RequestParam long phoneNumber) {
		System.out.println("Calling register method");
		System.out.println(username + "\t" + password + "\t" + phoneNumber);
		return new ModelAndView("/success.jsp", "user", username);
	}*/
	
	@RequestMapping(value= "/reg.do")
	public ModelAndView register(@ModelAttribute RegisterDTO dto) {
		System.out.println("Calling register method");
		System.out.println(dto.getUsername() + "\t" + dto.getPassword() + "\t" + dto.getPhoneNumber());
		return new ModelAndView("/success.jsp", "user", dto.getUsername());
	}
}

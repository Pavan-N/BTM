package com.jspiders.spring.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.spring.bean.ATMBean;

public class AppTester {

	public static void main(String[] args) {
		String fileName = "context.xml";
		ApplicationContext container = new 
				ClassPathXmlApplicationContext(fileName);
		ATMBean bean = container.getBean(ATMBean.class);
		ATMBean atmBean = container.getBean("atm1", ATMBean.class);
		//atmBean.setName("SBI");
		//atmBean.setBranch("BTM");
		//atmBean.setSize(30);
		System.out.println(atmBean);
		atmBean.getLotOfMoney();
	}

}

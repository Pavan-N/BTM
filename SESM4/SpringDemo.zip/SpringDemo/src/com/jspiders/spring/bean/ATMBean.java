package com.jspiders.spring.bean;

import java.io.Serializable;

public class ATMBean implements Serializable {

	private String name;
	private int size;
	private String branch;
	
	public ATMBean() {
		System.out.println(this.getClass().getSimpleName() + "object created by the container");
	}

	//getters and setters
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}
	
	public void getLotOfMoney() 
	{
		System.out.println("Withdrawing money from atm..");
	}

	@Override
	public String toString() {
		return "ATMBean [name=" + name + ", size=" + size + ", branch="
				+ branch + "]";
	}
	

}

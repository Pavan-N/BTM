package com.jspiders.feedback.service;

import org.springframework.stereotype.Service;

import com.jspiders.feedback.dto.RegisterDTO;

@Service
public class RegisterService {

	public boolean register(RegisterDTO dto) {
		System.out.println("Inside service");
		return true;
	}
}

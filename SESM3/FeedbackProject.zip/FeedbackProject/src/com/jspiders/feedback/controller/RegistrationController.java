package com.jspiders.feedback.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.jspiders.feedback.dto.RegisterDTO;
import com.jspiders.feedback.service.RegisterService;

@Controller
@RequestMapping(value = "/")
public class RegistrationController {

	@Autowired
	private RegisterService service;
	
	public RegistrationController() {
		System.out.println(this.getClass().getSimpleName() + " created..");
	}
	
	@RequestMapping(value = "/register.do", method = RequestMethod.POST)
	public ModelAndView register(@ModelAttribute RegisterDTO dto) {
		System.out.println("Inside Controller..");
		service.register(dto);
		return new ModelAndView("/success.jsp", "name", dto.getName());
	}
}

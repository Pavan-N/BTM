package com.jspiders.spring.di.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.spring.di.bean.DeveloperBean;
import com.jspiders.spring.di.bean.InterviewBean;

public class SpringDITester {

	public static void main(String[] args) {
		String configFile = "context.xml";
		ApplicationContext container = 
				new ClassPathXmlApplicationContext(configFile);
		
		/*InterviewBean interviewBean = 
				container.getBean("interview", InterviewBean.class);
		interviewBean.clearInterview();
		System.out.println(interviewBean);*/
		
		DeveloperBean developerBean = container.getBean("developer", DeveloperBean.class);
		developerBean.search();
		
	}
}

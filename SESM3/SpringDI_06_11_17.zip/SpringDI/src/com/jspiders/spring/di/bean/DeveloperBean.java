package com.jspiders.spring.di.bean;

import java.io.Serializable;

public class DeveloperBean implements Serializable{
	
	public DeveloperBean() {
		System.out.println(this.getClass().getSimpleName() + " Created...");
	}

	public DeveloperBean(StackOverflowBean overflowBean) {
		this.overflowBean = overflowBean;
		System.out.println(this.getClass().getSimpleName() + " Created...");
	}

	private StackOverflowBean overflowBean;
	
	public StackOverflowBean getOverflowBean() {
		return overflowBean;
	}

	public void setOverflowBean(StackOverflowBean overflowBean) {
		this.overflowBean = overflowBean;
	}
	
	public void search() {
		System.out.println("Searching for solution");
		overflowBean.provideSolution();
	}
	
}

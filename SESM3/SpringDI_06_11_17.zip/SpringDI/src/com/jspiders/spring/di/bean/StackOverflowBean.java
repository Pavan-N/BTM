package com.jspiders.spring.di.bean;

public class StackOverflowBean {

	public StackOverflowBean() {
		System.out.println(this.getClass().getSimpleName() + " Created...");
	}
	
	public void provideSolution() {
		System.out.println("Copy paste the content to "
				+ "resolve the exception");
	}
}

package com.jspiders.spring.core.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.spring.core.bean.CarBean;

public class AppTester {

	public static void main(String[] args) {
		String configFileName = "context.xml";
		
		//CarBean bean = new CarBean();
		
		ApplicationContext container = new 
				ClassPathXmlApplicationContext(configFileName);
		CarBean bean = container.getBean("car",CarBean.class);
		
		bean.drive();
		System.out.println(bean);

	}

}

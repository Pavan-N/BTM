package com.jspiders.spring.core.bean;

import java.io.Serializable;

public class CarBean implements Serializable {

	public CarBean() {
		System.out.println(this.getClass().getSimpleName() + " Created...");
	}

	public CarBean(int speed, String model) {
		System.out.println(this.getClass().getSimpleName() + " Created using Parameterised constructor");
		this.model = model;
		this.speed = speed;
	}

	public CarBean(String model, int speed) {
		System.out.println(this.getClass().getSimpleName() + " Created using Parameterised constructor(String, int)");
		this.model = model;
		this.speed = speed;
	}



	private String model;
	private int speed;

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public void drive() {
		System.out.println("Driving " + model + " car at " + speed + "km/hr");
	}

	@Override
	public String toString() {
		return "CarBean [model=" + model + ", speed=" + speed + "]";
	}
	
}

package com.jspiders.spring.di.bean;

import java.io.Serializable;

public class MockBean implements Serializable {

	public MockBean() {
		System.out.println(this.getClass().getSimpleName() + " Created!!!");
	}

	private int rating;
	private String course;

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}
	
	public boolean attendMockInterview() {
		if (rating > 1) {
			return true;
		}
		else 
			return false;
	}

	@Override
	public String toString() {
		return "MockBean [rating=" + rating + ", course=" + course + "]";
	}

}

package com.jspiders.spring.di.bean;

import java.io.Serializable;

public class InterviewBean implements Serializable {

	public InterviewBean() {
		System.out.println(this.getClass().getSimpleName() + " Created!!!");
	}

	private String skills;
	private double ctc;
	private int yearsOfExperience;
	private MockBean mockBean;

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public double getCtc() {
		return ctc;
	}

	public void setCtc(double ctc) {
		this.ctc = ctc;
	}

	public int getYearsOfExperience() {
		return yearsOfExperience;
	}

	public void setYearsOfExperience(int yearsOfExperience) {
		this.yearsOfExperience = yearsOfExperience;
	}
	
	public MockBean getMockBean() {
		return mockBean;
	}

	public void setMockBean(MockBean mockBean) {
		this.mockBean = mockBean;
	}

	public void clearInterview() {
		if (mockBean.attendMockInterview()) {
			System.out.println("Interview scheduled and cleared successfully");
		} else {
			System.out.println("No Interview!! nO Job");
		}
	}

	@Override
	public String toString() {
		return "InterviewBean [skills=" + skills + ", ctc=" + ctc
				+ ", yearsOfExperience=" + yearsOfExperience + ", mockBean="
				+ mockBean + "]";
	}
	
}

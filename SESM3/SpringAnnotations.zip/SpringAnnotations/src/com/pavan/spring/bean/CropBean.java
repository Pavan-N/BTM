package com.pavan.spring.bean;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CropBean implements Serializable {

	private String name;
	private int duration;
	private RainBean rain;

	public CropBean() {
		System.out.println(this.getClass().getSimpleName() + " created...");
	}
	
	@Autowired
	public CropBean(RainBean rain) {
		this.rain = rain;
		System.out.println(this.getClass().getSimpleName() + " created...");
	}

	public String getName() {
		return name;
	}

	@Value(value = "Paddy")
	public void setName(String name) {
		this.name = name;
	}

	public int getDuration() {
		return duration;
	}

	@Value("6")
	public void setDuration(int duration) {
		this.duration = duration;
	}

	public void grow() {
		rain.moderateRainFall();
		System.out.println("Growing " + name +"crops for " + duration + " duration");
	}
	
	
}

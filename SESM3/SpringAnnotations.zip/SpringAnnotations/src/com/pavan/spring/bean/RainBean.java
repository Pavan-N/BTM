package com.pavan.spring.bean;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class RainBean implements Serializable {

	private double measure;

	@Autowired
	public RainBean(@Value("12.12") double measure) {
		this.measure = measure;
		System.out.println(this.getClass().getSimpleName() + " created..");
	}
	
	public void moderateRainFall() {
		System.out.println("Appropriate amount of RainFall for our crops");
	}
}

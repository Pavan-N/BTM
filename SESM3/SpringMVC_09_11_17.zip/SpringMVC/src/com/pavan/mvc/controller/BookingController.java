package com.pavan.mvc.controller;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;

@Component
@RequestMapping("/")
public class BookingController {

	public BookingController() {
		System.out.println(this.getClass().getSimpleName() + " created/...");
	}

	@RequestMapping("/book.do")
	public String bookTicket() {
		System.out.println("Booking tickets..");
		return "/success.jsp";
	}

}

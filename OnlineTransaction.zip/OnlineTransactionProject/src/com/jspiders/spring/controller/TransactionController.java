package com.jspiders.spring.controller;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Component
//@RequestMapping("/")
public class TransactionController {

	@RequestMapping(value = "/send.do", method = RequestMethod.POST)
	public ModelAndView sendMoney(@RequestParam String reciever, @RequestParam double amount) {
		System.out.println(reciever + "\t" + amount);
		return new ModelAndView("/success.jsp", "amount", amount);
	}
	
	@RequestMapping(value = "/recieve.do", method = RequestMethod.POST)
	public ModelAndView recieveMoney(@RequestParam String reciever, @RequestParam double amount) {
		System.out.println(reciever + "\t" + amount);
		return new ModelAndView("/success.jsp", "amount", amount);
	}
	
}

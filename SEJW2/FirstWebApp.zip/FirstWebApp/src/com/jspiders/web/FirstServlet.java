package com.jspiders.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

//@WebServlet("/fs")
public class FirstServlet extends GenericServlet {

	@Override
	public void service(ServletRequest req, ServletResponse resp)
			throws ServletException, IOException {
		
		String htmlContent = "<html>"
								+ "<body>"
								+ "Welcome to FirstServlet"
								+ "</body>"
							+ "</html>";
		PrintWriter pw = resp.getWriter();
		pw.write(htmlContent);
		pw.flush();
		pw.close();
	}

}

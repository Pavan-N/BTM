package com.jspiders.dbApp;

public interface DBConstants {
	String DRIVER = "com.mysql.jdbc.Driver";
	String URL = "jdbc:mysql://localhost:3306/sejm2";
	String user = "root";
	String password = "root";
}

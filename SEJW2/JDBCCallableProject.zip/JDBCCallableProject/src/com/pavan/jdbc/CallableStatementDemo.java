package com.pavan.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

public class CallableStatementDemo {

	public static void main(String[] args) {
		Connection con = null;
		CallableStatement cstmt = null;
		String sql = "{call getUserById(?,?,?)}";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sejm2", "root", "root");
			cstmt = con.prepareCall(sql);
			cstmt.setInt(1, 2);
			cstmt.registerOutParameter(2, Types.VARCHAR);
			cstmt.registerOutParameter(3, Types.VARCHAR);
			
			String userName = null;
			String password = null;
			/*cstmt.execute();
			
			String userName = cstmt.getString(2);
			String password = cstmt.getString(3);*/
			
			ResultSet rs = cstmt.executeQuery();
			if (rs.next()) {
				userName = rs.getString(1);
				password = rs.getString(2);
			}
			System.out.println("username: " + userName + "\t password: " + password);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
	}

}

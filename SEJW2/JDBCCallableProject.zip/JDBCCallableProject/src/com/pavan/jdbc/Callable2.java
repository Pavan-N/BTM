package com.pavan.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

public class Callable2 {

	public static void main(String[] args) {
		Connection con = null;
		CallableStatement cstmt = null;
		String sql = "{call getAllUsers()}";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sejm2", "root", "root");
			cstmt = con.prepareCall(sql);
			
			String userName = null;
			String password = null;
			
			ResultSet rs = cstmt.executeQuery();
			while (rs.next()) {
				userName = rs.getString(2);
				password = rs.getString(3);
				System.out.println("username: " + userName + "\t password: " + password);
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

}

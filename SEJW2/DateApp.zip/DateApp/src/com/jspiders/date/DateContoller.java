package com.jspiders.date;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet("/date")
public class DateContoller extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ServletConfig config = getServletConfig();
		
		String url = config.getInitParameter("url");
		System.out.println("url: " + url);
		
		ServletContext context = getServletContext();
		
		String driverContext = context.getInitParameter("driver");
		System.out.println("Driver CLass: " + driverContext);
		
		Date d = new Date();
		PrintWriter out = resp.getWriter();
		out.println("<html>"
				+ "<body>"
				+ "The current system date is: " + d
				+ "</body>"
				+ "</html>");
		out.flush();
		out.close();
	}
}

package com.jspiders.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = "/login")
public class LoginController extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		/*RequestDispatcher rd = req.getRequestDispatcher("login.html");
		rd.include(req, resp);*/
		resp.sendRedirect("login.html");
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = req.getParameter("usr");
		String password = req.getParameter("pwd");
		req.getSession().invalidate();
		req.setAttribute("user", username);
		req.setAttribute("pass", password);
		
		RequestDispatcher rd = req.getRequestDispatcher("home");
		rd.include(req, resp);
	}
}

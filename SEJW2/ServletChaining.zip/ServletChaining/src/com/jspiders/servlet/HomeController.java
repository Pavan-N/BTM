package com.jspiders.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = "/home")
public class HomeController extends HttpServlet {
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/sejm2";
		String query = "Select * from user_table where p_username=? and p_password=?";
		
		try {
			Class.forName(driver);
			con = DriverManager.getConnection(url, "root", "root");
			pstmt = con.prepareStatement(query);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String user = (String) req.getAttribute("user");
		String password= (String) req.getAttribute("pass");

		try {
			pstmt.setString(1, user);
			pstmt.setString(2, password);
			rs = pstmt.executeQuery();
			
			if (rs != null) {
				if (rs.next()) {
					System.out.println("Valid user");
					PrintWriter out = resp.getWriter();
					out.println("<hmtl>"
							+ "<body>"
							+ "Welcome " + user 
							+ "</body>"
							+ "</html>");
				}
				else {
					System.out.println("Invalid user");
					RequestDispatcher rd = req.getRequestDispatcher("login.html");
					rd.forward(req, resp);
				}
			} 
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void destroy() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (con != null) {
				con.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}

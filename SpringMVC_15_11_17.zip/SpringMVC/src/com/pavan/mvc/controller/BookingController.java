package com.pavan.mvc.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Component
@RequestMapping("/")
public class BookingController {

	public BookingController() {
		System.out.println(this.getClass().getSimpleName() + " created/...");
	}

	/*@RequestMapping("/book.do")
	public String bookTicket(HttpServletRequest req) {
		String startingPoint = req.getParameter("start");
		String destination = req.getParameter ("destination");
		System.out.println("startingPoint: "+ startingPoint);
		System.out.println("destination: " + destination);
		System.out.println("Booking tickets..");
		return "/success.jsp";
	}*/
	
	/*@RequestMapping(value = "/book.do", method = RequestMethod.POST)
	public String bookTicket(@RequestParam String destination, @RequestParam String start) {
		System.out.println("startingPoint: "+ start);
		System.out.println("destination: " + destination);
		System.out.println("Booking tickets..");
		return "/success.jsp";
	}*/

	@RequestMapping(value = "/book.do", method = RequestMethod.POST)
	public ModelAndView bookTicket(@RequestParam String destination, @RequestParam String start) {
		return new ModelAndView("/success.jsp", "destination", destination);
		//return new ModelAndView("/success.jsp");
	}
	
}

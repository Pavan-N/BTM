package com.jspiders.di.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.di.bean.GunBean;

public class DITester {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
		
		GunBean gunBean = context.getBean(GunBean.class);
		gunBean.fireToKill();
	}

}

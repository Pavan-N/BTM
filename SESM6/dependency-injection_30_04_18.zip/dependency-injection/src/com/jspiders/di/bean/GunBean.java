package com.jspiders.di.bean;

import java.io.Serializable;

public class GunBean implements Serializable {

	private BulletBean bullet;
	
	public GunBean() {
		System.out.println(this.getClass().getSimpleName() + " created!");
	}
	
	public GunBean(BulletBean bullet) {
		this();
		this.bullet = bullet;
	}



	public void fireToKill() {
		System.out.println("Bullet fired");
		bullet.burnOrExplode();
	}

	public BulletBean getBullet() {
		return bullet;
	}

	public void setBullet(BulletBean bullet) {
		this.bullet = bullet;
	}

}

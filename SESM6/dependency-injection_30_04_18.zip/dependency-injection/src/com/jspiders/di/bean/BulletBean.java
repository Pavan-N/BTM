package com.jspiders.di.bean;

import java.io.Serializable;

public class BulletBean implements Serializable {
	
	public BulletBean() {
		System.out.println(this.getClass().getSimpleName() + " created!");
	}

	public void burnOrExplode() {
		System.out.println("Bullet is burnt/exploded");
	}
}

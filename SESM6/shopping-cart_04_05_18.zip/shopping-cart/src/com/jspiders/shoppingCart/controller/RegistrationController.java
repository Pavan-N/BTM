package com.jspiders.shoppingCart.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Component
@RequestMapping("/")
public class RegistrationController {
	
	public RegistrationController() {
		System.out.println(this.getClass().getSimpleName() + " created!!");
	}

	/*@RequestMapping("/register.do")
	public String registerUser(HttpServletRequest req) {
		String userName = req.getParameter("userName");
		String password = req.getParameter("password");
		String mobile = req.getParameter("mobileNumber");
		long mobileNumber = Long.parseLong(mobile);
		System.out.println("userName: " + userName);
		System.out.println("password: " + password);
		System.out.println("mobileNumber: " + mobileNumber);
		req.setAttribute("user", userName);
		return "mulitplePage.jsp";
	}*/
	
	@RequestMapping("/register.do")
	public ModelAndView registerUser(@RequestParam String userName, @RequestParam String password, @RequestParam long mobileNumber) {
		System.out.println("userName: " + userName);
		System.out.println("password: " + password);
		System.out.println("mobileNumber: " + mobileNumber);
		
		return new ModelAndView("mulitplePage.jsp", "user", userName);
	}
	
	@RequestMapping("/update.do")
	public String updateRegisteredUser() {
		System.out.println("updateRegisteredUser() called");
		return "update.jsp";
	}
}

package com.jspiders.shoppingCart.controller;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;

@Component
@RequestMapping("/")
public class RegistrationController {

	@RequestMapping("/register.do")
	public String registerUser() {
		System.out.println("registerUser() called");
		return "mulitplePage.jsp";
	}
}

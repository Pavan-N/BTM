package com.jspiders.spring.bean;

import java.io.Serializable;

public class IplBean implements Serializable {

	private int iplId;
	private int noOfTeams;
	private long winningPrice;
	private String season;

	public int getIplId() {
		return iplId;
	}

	public void setIplId(int iplId) {
		this.iplId = iplId;
	}

	public int getNoOfTeams() {
		return noOfTeams;
	}

	public void setNoOfTeams(int noOfTeams) {
		this.noOfTeams = noOfTeams;
	}

	public long getWinningPrice() {
		return winningPrice;
	}

	public void setWinningPrice(long winningPrice) {
		this.winningPrice = winningPrice;
	}
	
	public long makingMoney() {
		System.out.println("Making lots of moneythis(" + this.winningPrice + ") in season: " + this.season);
		System.out.println("No of Teams playing: " + this.noOfTeams) ;
		return this.winningPrice;
	}

	public String getSeason() {
		return season;
	}

	public void setSeason(String season) {
		this.season = season;
	}
}

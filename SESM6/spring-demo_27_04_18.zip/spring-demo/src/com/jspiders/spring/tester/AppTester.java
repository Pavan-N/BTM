package com.jspiders.spring.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.spring.bean.IplBean;

public class AppTester {

	public static void main(String[] args) {
		//IplBean iplBean = new IplBean();
		
		ApplicationContext container = new ClassPathXmlApplicationContext("context.xml");
		IplBean iplBean = container.getBean("ipl1", IplBean.class);
		
		
		long winningPrice = iplBean.makingMoney();
		System.out.println(winningPrice);

	}

}

package com.jspiders.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.jspiders.web.dto.UserDTO;
import com.jspiders.web.service.RegistrationService;

@Controller
@RequestMapping("/")
public class RegistrationController {

	@Autowired
	private RegistrationService registrationService;

	public RegistrationController() {
		System.out.println(this.getClass().getSimpleName() + " created!!");
	}

	@RequestMapping("/register.do")
	public ModelAndView registerUser(@ModelAttribute UserDTO userDTO, HttpServletRequest req) {
		boolean flag = registrationService.registerUser(userDTO);
		if (flag) {
			return new ModelAndView("success.jsp", "username", userDTO.getUserName());
		} else {
			return new ModelAndView("error.jsp");
		}
	}
}

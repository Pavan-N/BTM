package com.jspiders.web.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jspiders.web.dao.RegistrationDAO;
import com.jspiders.web.dto.UserDTO;

@Service
public class RegistrationService {

	@Autowired
	private RegistrationDAO registrationDAO;
	
	public boolean registerUser(UserDTO dto) {
		return registrationDAO.saveUser(dto);
	}
}

package com.jspiders.web.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jspiders.web.dto.UserDTO;

@Repository
public class RegistrationDAO {

	@Autowired
	private SessionFactory factory;
	
	public boolean saveUser(UserDTO userDTO) {
		boolean flag = false;
		Transaction tx = null;
		try(Session session = factory.openSession()) {
			tx = session.beginTransaction();
			session.save(userDTO);
			tx.commit();
			flag = true;
		} catch (HibernateException e) {
			e.printStackTrace();
			tx.rollback();
		}
		return flag;
	}
}

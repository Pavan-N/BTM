package com.jspiders.annotation.bean;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ElectionBean implements Serializable {
	@Value("100000000")
	private int noOfVoters;

	@Autowired
	private VoterBean voter;
	
	public ElectionBean() {
		System.out.println(this.getClass().getSimpleName() + " created");
	}
	
	//@Autowired
	public ElectionBean(VoterBean voter) {
		this();
		this.voter = voter;
	}
	
	public int getNoOfVoters() {
		return noOfVoters;
	}

	public void setNoOfVoters(int noOfVoters) {
		this.noOfVoters = noOfVoters;
	}

	public VoterBean getVoter() {
		return voter;
	}

	public void setVoter(VoterBean voter) {
		this.voter = voter;
	}

	public void conductElection() {
		System.out.println("conducting Election...");
		voter.vote();
	}

}

package com.jspiders.annotation.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component
public class VoterBean {
	@Value(value = "XYZ12345")
	private String voterID;
	
	public VoterBean() {
		System.out.println(this.getClass().getSimpleName() + " created");
	}
	
	public String getVoterID() {
		return voterID;
	}

	public void setVoterID(String voterID) {
		this.voterID = voterID;
	}

	public void vote() {
		System.out.println("Voting with ID: " + voterID);
	}

}

package com.jspiders.annotation.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.annotation.bean.ElectionBean;

public class AnnotationTester {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
		ElectionBean electionBean = context.getBean(ElectionBean.class);
		electionBean.conductElection();
		System.out.println("No of Voters: " + electionBean.getNoOfVoters());
	}
	 

}

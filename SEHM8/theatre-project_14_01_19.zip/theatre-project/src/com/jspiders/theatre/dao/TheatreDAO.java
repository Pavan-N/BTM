package com.jspiders.theatre.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.jspiders.theatre.dto.TheatreDTO;

public class TheatreDAO {

	public void saveTheatre(TheatreDTO theatreDTO) {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = null;
		Transaction transaction = null;
		try {
			session = factory.openSession();
			transaction = session.beginTransaction();
			session.save(theatreDTO);
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	public TheatreDTO getTheatreById(int primaryKey) {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = null;
		TheatreDTO theatreDTO = null;
		try {
			session = factory.openSession();
			theatreDTO = session.get(TheatreDTO.class, new Integer(primaryKey));
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return theatreDTO;
	}
}

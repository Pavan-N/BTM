package com.jspiders.spring.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class RechargeController {

	/*@PostMapping("/recharge.do")
	public String rechargeMobile(HttpServletRequest req) {
		String mobileNumber = req.getParameter("mobileNumber");
		String operator = req.getParameter("operator");
		String amount = req.getParameter("amount");
		
		System.out.println(mobileNumber + "\t" + operator + "\t" + amount);
		
		return "success.jsp";
	}*/
	
	@PostMapping("/recharge.do")
	public String rechargeMobile(@RequestParam long mobileNumber, 
								 @RequestParam String operator, 
								 @RequestParam double amount) {
		
		System.out.println(mobileNumber + "\t" + operator + "\t" + amount);
		
		return "success.jsp";
	}
}

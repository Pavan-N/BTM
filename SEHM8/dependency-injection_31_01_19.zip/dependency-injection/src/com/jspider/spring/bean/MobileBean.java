package com.jspider.spring.bean;

import java.io.Serializable;

public class MobileBean implements Serializable {
	private String model;
	private double cost;
	private String color;
	private BatteryBean batteryBean;
	
	public MobileBean() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public BatteryBean getBatteryBean() {
		return batteryBean;
	}

	public void setBatteryBean(BatteryBean batteryBean) {
		this.batteryBean = batteryBean;
	}

	public void call() {
		batteryBean.supplyPower();
		System.out.println("make Calls with mobile");
	}
	
	
}

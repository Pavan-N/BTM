package com.jspider.spring.bean;

import java.io.Serializable;

public class BatteryBean implements Serializable {
	private String type;
	private int capacity;
	
	public BatteryBean() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public void supplyPower() {
		System.out.println("provide power supply to the device");
	}
	
	
}

package com.jspider.spring.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspider.spring.bean.MobileBean;

public class MainTester {
	
	public static void main(String[] args) {
		String configFile = "context.xml";
		ApplicationContext container = new ClassPathXmlApplicationContext(configFile);
		MobileBean mobileBean = container.getBean(MobileBean.class);
		mobileBean.call();
		
	}

}

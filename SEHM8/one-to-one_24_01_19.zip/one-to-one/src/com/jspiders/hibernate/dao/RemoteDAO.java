package com.jspiders.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.jspiders.hibernate.dto.RemoteDTO;
import com.jspiders.hibernate.dto.TvDTO;
import com.jspiders.hibernate.util.HibernateUtil;

public class RemoteDAO {
	
	SessionFactory factory = HibernateUtil.getSessionFactory();

	public void saveRemoteAndTv(TvDTO tvDTO, RemoteDTO remoteDTO) {
		Transaction transaction = null;
		try(Session session = factory.openSession();) {
			transaction = session.beginTransaction();
			session.save(tvDTO);
			session.save(remoteDTO);
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
		}
	}

	public RemoteDTO getRemoteById(int identifier) {
		RemoteDTO remoteDTO = null;
		try(Session session = factory.openSession()) {
			remoteDTO = session.get(RemoteDTO.class, new Integer(identifier));
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return remoteDTO;
	}
}

package com.jspiders.hibernate.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "remote_table")
public class RemoteDTO implements Serializable {

	@Id
	@GenericGenerator(name = "autoInc", strategy = "increment")
	@GeneratedValue(generator = "autoInc")
	@Column(name = "remote_id")
	private int remoteId;
	@Column(name = "no_of_batteries")
	private int noOfBatteries;
	@Column(name = "r_colour")
	private String remoteColour;
	@Column(name = "r_price")
	private double price;

	@OneToOne
	@JoinColumn(name = "t_id")
	private TvDTO tvDTO;

	public RemoteDTO() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	public int getRemoteId() {
		return remoteId;
	}

	public void setRemoteId(int remoteId) {
		this.remoteId = remoteId;
	}

	public int getNoOfBatteries() {
		return noOfBatteries;
	}

	public void setNoOfBatteries(int noOfBatteries) {
		this.noOfBatteries = noOfBatteries;
	}

	public String getRemoteColour() {
		return remoteColour;
	}

	public void setRemoteColour(String remoteColour) {
		this.remoteColour = remoteColour;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public TvDTO getTvDTO() {
		return tvDTO;
	}

	public void setTvDTO(TvDTO tvDTO) {
		this.tvDTO = tvDTO;
	}

}

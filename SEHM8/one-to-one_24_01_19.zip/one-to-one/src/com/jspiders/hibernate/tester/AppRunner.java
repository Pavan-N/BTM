package com.jspiders.hibernate.tester;

import com.jspiders.hibernate.dao.RemoteDAO;
import com.jspiders.hibernate.dto.RemoteDTO;
import com.jspiders.hibernate.dto.TvDTO;

public class AppRunner {

	public static void main(String[] args) {
		RemoteDAO remoteDAO = new RemoteDAO();
		
		/*
		TvDTO tvDTO = new TvDTO();
		tvDTO.setModel("SAMSUNG");
		tvDTO.setPrice(53999.99);
		tvDTO.setSize(44.2);
		tvDTO.setType("4K");
		
		
		RemoteDTO remoteDTO = new RemoteDTO();
		remoteDTO.setRemoteColour("Pink");
		remoteDTO.setPrice(99.99);
		remoteDTO.setNoOfBatteries(1);
		
		remoteDTO.setTvDTO(tvDTO);

		
		remoteDAO.saveRemoteAndTv(tvDTO, remoteDTO);
		*/

		RemoteDTO remoteDTO = remoteDAO.getRemoteById(1);
		if (remoteDTO != null) {
			TvDTO tvDTO = remoteDTO.getTvDTO();
			System.out.println("---------------------------------------------");
			System.out.println("Remote colour: " + remoteDTO.getRemoteColour());
			System.out.println("Remote price: " + remoteDTO.getPrice());
			System.out.println("TV Model/Brand: " + tvDTO.getModel());
			System.out.println("TV Type: " + tvDTO.getType());
			System.out.println("TV Price: " + tvDTO.getPrice());
		}
	}

}

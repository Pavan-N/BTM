package com.jspyder.hibernate.dao;

import com.jspiders.hibernate.util.HibernateUtil;
import com.jspyder.hibernate.dto.SportsDTO;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.sql.ordering.antlr.Factory;

public class SportsDao {
	SessionFactory factory = HibernateUtil.getSessionFactory();

	public Integer saveSports(SportsDTO sportsDTO) {
		Session session = null;
		Transaction transaction = null;
		Integer identifier = null;
		try {
			session = factory.openSession();
			transaction = session.beginTransaction();
			identifier = (Integer) session.save(sportsDTO);
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
		} finally {
			if (session != null)
				session.close();
		}
		return identifier;
	}
}

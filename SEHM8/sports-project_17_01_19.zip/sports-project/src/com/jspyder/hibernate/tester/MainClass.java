package com.jspyder.hibernate.tester;

import com.jspyder.hibernate.dao.SportsDao;
import com.jspyder.hibernate.dto.SportsDTO;

public class MainClass {

	public static void main(String[] args) {
		SportsDTO sportsDTO = new SportsDTO();
		
		sportsDTO.setSportName("Football");
		sportsDTO.setCategory("Outdoor");
		sportsDTO.setCashPrice(50000.50);
		sportsDTO.setNoOfPlayers(11);
		
		SportsDao sportsDao = new SportsDao();
		Integer identifier = sportsDao.saveSports(sportsDTO);
		
		if (identifier != null) {
			System.out.println("Primary Key value: " + identifier);
		} else {
			System.out.println("Save operation unsuccessful!!");
		}
	}

}

package com.jspiders.theatre.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.jspiders.theatre.dto.TheatreDTO;
import com.jspiders.theatre.util.HibernateUtil;

public class TheatreDAO {

	SessionFactory factory = HibernateUtil.getSessionFactory();
	
	public void saveTheatre(TheatreDTO theatreDTO) {
		Session session = null;
		Transaction transaction = null;
		try {
			session = factory.openSession();
			transaction = session.beginTransaction();
			session.save(theatreDTO);
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			
			transaction.rollback();
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	public TheatreDTO getTheatreById(int primaryKey) {
		Session session = null;
		TheatreDTO theatreDTO = null;
		try {
			session = factory.openSession();
			theatreDTO = session.get(TheatreDTO.class, new Integer(primaryKey));
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return theatreDTO;
	}
	
	public void deleteTheatreById(int primaryKey) {
		Session session = null;
		Transaction transaction = null;
		TheatreDTO theatreDTO = null;
		try {
			session = factory.openSession();
			theatreDTO = session.get(TheatreDTO.class, new Integer(primaryKey));
			if (theatreDTO != null) {
				transaction = session.beginTransaction();
				session.delete(theatreDTO);
				transaction.commit();
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	public void updateTheatreNameById(int primaryKey, String theatreName) {
		Session session = null;
		Transaction transaction = null;
		try {
			session = factory.openSession();
			TheatreDTO theatreDTO = session.get(TheatreDTO.class, new Integer(primaryKey));
			if (theatreDTO != null) {
				transaction = session.beginTransaction();
				theatreDTO.setName(theatreName);
				session.update(theatreDTO);
				transaction.commit();
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
}

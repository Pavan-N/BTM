package com.jspiders.hibernate.tester;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.jspiders.hibernate.dao.PubDAO;
import com.jspiders.hibernate.dto.PubDTO;

public class MainClass {

	public static void main(String[] args) {
		PubDTO pubDTO = new PubDTO();
		
		pubDTO.setPubId(2);
		pubDTO.setDrinks("Blue Label");
		pubDTO.setEntryFee(2000.00);
		pubDTO.setFood("Pickle");
		pubDTO.setDj("Nagoor");

		
		PubDAO pubDAO = new PubDAO();
		pubDAO.savePub(pubDTO);
	}

}

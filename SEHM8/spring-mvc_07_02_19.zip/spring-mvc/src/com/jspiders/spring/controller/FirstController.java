package com.jspiders.spring.controller;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Component
@RequestMapping("/")
//@Controller
public class FirstController {

	@GetMapping("/firstProgram.do")
	//@RequestMapping(value = "/firstProgram.do", method = RequestMethod.GET)
	public String firstOperation() {
		return "welcome.jsp";
	}
}

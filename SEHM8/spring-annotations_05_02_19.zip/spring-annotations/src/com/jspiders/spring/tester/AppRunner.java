package com.jspiders.spring.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.spring.bean.CaptainBean;
import com.jspiders.spring.bean.TeamBean;

public class AppRunner {

	public static void main(String[] args) {
		String configFileName = "context.xml";
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext(configFileName);
		
		TeamBean teamBean = ctx.getBean(TeamBean.class);
		
		if (teamBean != null) {
			teamBean.play();
			System.out.println(teamBean.getSportsName());
			System.out.println(teamBean.getTeamName());
			System.out.println(teamBean.getNoOfPlayers());
		}

		CaptainBean captainBean = ctx.getBean(CaptainBean.class);
		if (captainBean != null) {
			System.out.println("------------------------------------------");
			System.out.println(captainBean.getCaptainName());
		}
	}

}

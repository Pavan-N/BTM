package com.jspiders.spring.bean;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class TeamBean implements Serializable {

	@Value(value = "Barcelona")
	private String teamName;
	private String sportsName;
	@Value("11")
	private int noOfPlayers;
	
	
	private CaptainBean captainBean;
	
	public TeamBean() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}
	
	@Autowired
	public TeamBean(CaptainBean captainBean) {
		this.captainBean = captainBean;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	
	public String getSportsName() {
		return sportsName;
	}

	@Value("Football")
	public void setSportsName(String sportsName) {
		this.sportsName = sportsName;
	}

	public int getNoOfPlayers() {
		return noOfPlayers;
	}

	public void setNoOfPlayers(int noOfPlayers) {
		this.noOfPlayers = noOfPlayers;
	}

	public CaptainBean getCaptainBean() {
		return captainBean;
	}

	public void setCaptainBean(CaptainBean captainBean) {
		this.captainBean = captainBean;
	}

	public void play() {
		captainBean.lead();
		System.out.println("Playing.....");
	}
	
}

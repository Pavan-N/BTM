package com.jspiders.spring.bean;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CaptainBean implements Serializable {

	private String captainName;
	
	@Autowired
	public CaptainBean(@Value("Messi") String captainName) {
		this.captainName = captainName;
	}
	
	public CaptainBean() {
	}

	public String getCaptainName() {
		return captainName;
	}

	public void setCaptainName(String captainName) {
		this.captainName = captainName;
	}

	public void lead() {
		System.out.println("Leading the team...");
	}
}

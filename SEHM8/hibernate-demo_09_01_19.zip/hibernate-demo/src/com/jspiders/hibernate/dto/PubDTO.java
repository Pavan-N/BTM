package com.jspiders.hibernate.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "pub_table")
public class PubDTO implements Serializable {

	@Id
	@Column(name = "pub_id")
	private int pubId;
	@Column(name = "drinks")
	private String drinks;
	@Column(name = "dj")
	private String dj;
	@Column(name = "entry_fee")
	private double entryFee;
	@Column(name = "food")
	private String food;

	public PubDTO() {
		System.out.println("PubDTO object created");
	}
	
	public int getPubId() {
		return pubId;
	}

	public void setPubId(int pubId) {
		this.pubId = pubId;
	}

	public String getDrinks() {
		return drinks;
	}

	public void setDrinks(String drinks) {
		this.drinks = drinks;
	}

	public String getDj() {
		return dj;
	}

	public void setDj(String dj) {
		this.dj = dj;
	}

	public double getEntryFee() {
		return entryFee;
	}

	public void setEntryFee(double entryFee) {
		this.entryFee = entryFee;
	}

	public String getFood() {
		return food;
	}

	public void setFood(String food) {
		this.food = food;
	}

}

package com.jspiders.hibernate.tester;

import com.jspiders.hibernate.dto.PubDTO;

public class MainClass {

	public static void main(String[] args) {
		PubDTO pubDTO = new PubDTO();
		
		pubDTO.setPubId(1);
		pubDTO.setDrinks("Old Monk");
		pubDTO.setEntryFee(2000.0);
		pubDTO.setFood("Groundnut/Pickle");
		pubDTO.setDj("Martin");

		System.out.println("Drinks: " + pubDTO.getDrinks());
		
	}

}

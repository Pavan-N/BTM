package com.jspiders.theatre.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.jspiders.theatre.dto.TheatreDTO;
import com.jspiders.theatre.util.HibernateUtil;

public class TheatreDAO {

	SessionFactory factory = HibernateUtil.getSessionFactory();
	
	public void saveTheatre(TheatreDTO theatreDTO) {
		Session session = null;
		Transaction transaction = null;
		try {
			session = factory.openSession();
			transaction = session.beginTransaction();
			session.save(theatreDTO);
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	public TheatreDTO getTheatreById(int primaryKey) {
		Session session = null;
		TheatreDTO theatreDTO = null;
		try {
			session = factory.openSession();
			theatreDTO = session.get(TheatreDTO.class, new Integer(primaryKey));
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return theatreDTO;
	}
	
	public TheatreDTO deleteTheatreById(int primaryKey) {
		Session session = null;
		Transaction transaction = null;
		TheatreDTO theatreDTO = null;
		try {
			session = factory.openSession();
			transaction = session.beginTransaction();
			theatreDTO = session.get(TheatreDTO.class, new Integer(primaryKey));
			if (theatreDTO != null) {
				session.delete(theatreDTO);
			}
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return theatreDTO;
	}
}

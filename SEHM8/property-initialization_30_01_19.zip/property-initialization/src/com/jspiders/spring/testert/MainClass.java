package com.jspiders.spring.testert;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.spring.bean.FoodBean;

public class MainClass {

	public static void main(String[] args) {
		String configFileName = "context.xml";
		ApplicationContext context = new ClassPathXmlApplicationContext(configFileName);
		
		FoodBean foodBean = context.getBean("foodBean" , FoodBean.class);
		
		if (foodBean != null) {
			foodBean.eat();
			System.out.println("Food Name: " + foodBean.getFoodName());
			System.out.println("Food type: " + foodBean.getType());
			System.out.println("Food price: " + foodBean.getCost());
			System.out.println("Food quantity: " + foodBean.getQuantity());
		}
	}

}

package com.jspiders.spring.bean;

import java.io.Serializable;

public class FoodBean implements Serializable {

	private String foodName;
	private String type;
	private double cost;
	private int quantity;

	public FoodBean() {
		System.out.println(this.getClass().getSimpleName() + " object created by calling default constructor");
	}
	
	public FoodBean(String nameOfTheFood, double foodCost) {
		System.out.println(this.getClass().getSimpleName() + " object created by calling parameterized constructor");
		this.foodName = nameOfTheFood;
		this.cost = foodCost;
	}

	public String getFoodName() {
		return foodName;
	}

	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public void eat() {
		System.out.println("Eating food");
	}

}

package com.jspiders.hibernate.tester;

import com.jspiders.hibernate.dao.RemoteDAO;
import com.jspiders.hibernate.dao.TvDAO;
import com.jspiders.hibernate.dto.RemoteDTO;
import com.jspiders.hibernate.dto.TvDTO;

public class AppRunner {

	public static void main(String[] args) {
		RemoteDAO remoteDAO = new RemoteDAO();
		TvDAO tvDAO = new TvDAO();
		
		TvDTO tvDTO = new TvDTO();
		tvDTO.setModel("Micromax");
		tvDTO.setPrice(23889.99);
		tvDTO.setSize(54.5);
		tvDTO.setType("QHD");
		
		
		RemoteDTO remoteDTO = new RemoteDTO();
		remoteDTO.setRemoteColour("Black");
		remoteDTO.setPrice(59.99);
		remoteDTO.setNoOfBatteries(2);
		
		remoteDTO.setTvDTO(tvDTO);
		tvDTO.setRemoteDTO(remoteDTO);

		//remoteDAO.saveRemote(remoteDTO);
		tvDAO.saveTv(tvDTO);
		

		/*RemoteDTO remoteDTO = remoteDAO.getRemoteById(1);
		if (remoteDTO != null) {
			TvDTO tvDTO = remoteDTO.getTvDTO();
			System.out.println("---------------------------------------------");
			System.out.println("Remote colour: " + remoteDTO.getRemoteColour());
			System.out.println("Remote price: " + remoteDTO.getPrice());
			System.out.println("TV Model/Brand: " + tvDTO.getModel());
			System.out.println("TV Type: " + tvDTO.getType());
			System.out.println("TV Price: " + tvDTO.getPrice());
		}*/
	}

}

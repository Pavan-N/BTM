package com.jspiders.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.jspiders.hibernate.dto.TvDTO;
import com.jspiders.hibernate.util.HibernateUtil;

public class TvDAO {

	SessionFactory factory = HibernateUtil.getSessionFactory();
	
	public void saveTv(TvDTO tvDTO) {
		Transaction transaction = null;
		try(Session session = factory.openSession();) {
			transaction = session.beginTransaction();
			session.save(tvDTO);
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
		}
	}

	
}

package com.jspyder.hibernate.dto;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="sports_table")
public class SportsDTO implements Serializable
{
	@Id
	@GenericGenerator(name = "auto", strategy = "increment")
	@GeneratedValue(generator = "auto")
	@Column(name="sports_id")
	private int sportsId;
	@Column(name="no_of_players")
	private int noOfPlayers;
	@Column(name="sport_name")
	private String sportName;
	@Column(name="category")
	private String category;
	@Column(name="cash_price")
	private double cashPrice;
	
	public SportsDTO() 
	{
		System.out.println("sportsDTO object is created");
}
	public int getSportsId() {
		return sportsId;
	}
	public void setSportsId(int sportsId) {
		this.sportsId = sportsId;
	}
	public int getNoOfPlayers() {
		return noOfPlayers;
	}
	public void setNoOfPlayers(int noOfPlayers) {
		this.noOfPlayers = noOfPlayers;
	}
	public String getSportName() {
		return sportName;
	}
	public void setSportName(String sportName) {
		this.sportName = sportName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getCashPrice() {
		return cashPrice;
	}
	public void setCashPrice(double cashPrice) {
		this.cashPrice = cashPrice;
	}
}

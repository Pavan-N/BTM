package com.jspyder.hibernate.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.jspiders.hibernate.util.HibernateUtil;
import com.jspyder.hibernate.dto.SportsDTO;

public class SportsDao {
	SessionFactory factory = HibernateUtil.getSessionFactory();

	public Integer saveSports(SportsDTO sportsDTO) {
		Session session = null;
		Transaction transaction = null;
		Integer identifier = null;
		try {
			session = factory.openSession();
			transaction = session.beginTransaction();
			identifier = (Integer) session.save(sportsDTO);
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
		} finally {
			if (session != null)
				session.close();
		}
		return identifier;
	}
	
	public int getNoOFPlayersBySportName(String sportsName) {
		int noOfPlayers = 0;
		try(Session session = factory.openSession();) {
			String hqlQuery = "SELECT sports.noOfPlayers FROM SportsDTO sports "
					+ "WHERE sports.sportName = :sprtName";
			Query query = session.createQuery(hqlQuery);
			query.setParameter("sprtName", sportsName);
			noOfPlayers = (int) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return noOfPlayers;
	}
	
	
	public SportsDTO fecthSportsByNoOfPlayers(int playersCount) {
		SportsDTO sportsDTO = null;
		try(Session session = factory.openSession();) {
			String hqlQuery = "SELECT sports FROM SportsDTO sports WHERE sports.noOfPlayers = :noOfPlyrs";
			Query query = session.createQuery(hqlQuery);
			query.setParameter("noOfPlyrs", playersCount);
			sportsDTO = (SportsDTO) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return sportsDTO;
	}
	
	public int updateSportCategoryBySportName(String sportCategory, String sportsName) {
		Transaction transaction = null;
		int noOfRowsAffected = 0;
		try(Session session = factory.openSession();) {
			transaction = session.beginTransaction();
			String hqlQuery = "UPDATE SportsDTO sports SET sports.category = :sprtCategory "
					+ "WHERE sports.sportName = :sprtName";
			Query query = session.createQuery(hqlQuery);
			query.setParameter("sprtName", sportsName);
			query.setParameter("sprtCategory", sportCategory);
			noOfRowsAffected = query.executeUpdate();
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
		}
		return noOfRowsAffected;
	}
	
	public int deleteSportByCashPrice(double cashPrice) {
		Transaction transaction = null;
		int noOfRowsAffected = 0;
		try(Session session = factory.openSession();) {
			transaction = session.beginTransaction();
			String hqlQuery = "DELETE FROM SportsDTO sports WHERE sports.cashPrice < :price";
			Query query = session.createQuery(hqlQuery);
			query.setParameter("price", cashPrice);
			noOfRowsAffected = query.executeUpdate();
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
		}
		return noOfRowsAffected;
	}
	
	public List<SportsDTO> fecthSportsByCategory(String sportCategory) {
		List<SportsDTO> sportsDTOList = null;
		try(Session session = factory.openSession();) {
			String hqlQuery = "SELECT sports FROM SportsDTO sports WHERE sports.category = :category";
			Query query = session.createQuery(hqlQuery);
			query.setParameter("category", sportCategory);
			sportsDTOList = query.list();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return sportsDTOList;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public List<String> fetchSportNameByCategory(String sportCategory) {
		List<String> sportsNameList = null;
		try(Session session = factory.openSession();) {
			String hqlquery = "SELECT sports.sportName FROM SportsDTO sports WHERE sports.category=:category";
			Query query = session.createQuery(hqlquery);
			query.setParameter("category", sportCategory);
			sportsNameList = query.list();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return sportsNameList;
	}
	
	
	
	
	
	
	
}

package com.jspyder.hibernate.tester;

import java.util.List;

import com.jspyder.hibernate.dao.SportsDao;
import com.jspyder.hibernate.dto.SportsDTO;

public class MainClass {

	public static void main(String[] args) {
		SportsDao sportsDao = new SportsDao();
		
		/*SportsDTO sportsDTO = new SportsDTO();
		
		sportsDTO.setSportName("Hockey");
		sportsDTO.setCategory("Outdoor");
		sportsDTO.setCashPrice(300000.50);
		sportsDTO.setNoOfPlayers(11);
		
		
		Integer identifier = sportsDao.saveSports(sportsDTO);
		
		if (identifier != null) {
			System.out.println("Primary Key value: " + identifier);
		} else {
			System.out.println("Save operation unsuccessful!!");
		}*/
		
		/*int noOFPlayers = sportsDao.getNoOFPlayersBySportName("Football");
		System.out.println(noOFPlayers);*/
		
		/*int rowsAffected = sportsDao.updateSportCategoryBySportName("Indoor/Outdoor", "Football");
		System.out.println(rowsAffected);*/
		
		/*int rowsDeleted = sportsDao.deleteSportByCashPrice(110501.50);
		System.out.println(rowsDeleted);*/
		
		/*SportsDTO sportsDTO = sportsDao.fecthSportsByNoOfPlayers(4);
		if (sportsDTO != null) {
			System.out.println(sportsDTO.getSportName());
			System.out.println(sportsDTO.getCategory());
		}*/
		
		/*List<SportsDTO> sportsList = sportsDao.fecthSportsByCategory("outdoor");
		
		for (SportsDTO sportsDTO : sportsList) {
			if (sportsDTO != null) {
				System.out.println("----------------------------------------------------------------");
				System.out.println("Sports Name: " + sportsDTO.getSportName());
				System.out.println("No Of Players: " + sportsDTO.getNoOfPlayers());
			}
		}*/
		
		List<String> sportsNameList = sportsDao.fetchSportNameByCategory("outdoor");
		
		for (String sportsName : sportsNameList) {
			if (sportsName != null) {
				System.out.println("----------------------------------------------------------------");
				System.out.println("Sports Name: " + sportsName);
			}
		}
	}
	
	
	/*
	 ApplicationDTO {
	 	int applicationId;
	 	String appName;
	 	double appVersion;
	 	String type;
	 	double price;
	 }
	 
	 ApplicationDAO
	 	Integer saveApplication(ApplicationDTO applicationDTO) {}
	 	
	 	void saveListOfApplications(List<ApplicationDTO> applicationDTOsList) {}
	 	
	 	double getApplicationVersionByName(String appName) {}
	 
	 	String getAppTypeByName(String appName) {}
	 	
	 	double getAppPriceByNameAndType(String appName, String appType) {}
	 	
	 	int updateAppTypeByName(String appType, String appName) {}
	 	
	 	int updateAppPriceByAppType(double appPrice, String appType) {}
	 	
	 	int updateAppNameByAppName(String oldName, String newAppName) {}
	 	
	 	int deleteAppByName(String appName) {}
	 	
	 	int deleteAppByPriceAndName(double appPrice, String appName) {}
	 */
	
	
	
	
	
	

}

package com.jspiders.spring.bean;

import java.io.Serializable;

public class VehicleBean implements Serializable {

	private String vehicleName;
	
	public VehicleBean() {
		System.out.println("VehicleBean object created");
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
	
	public void ride() {
		System.out.println("Riding vehicle...");
	}
}

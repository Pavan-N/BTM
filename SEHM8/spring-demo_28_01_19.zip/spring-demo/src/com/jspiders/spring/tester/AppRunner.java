package com.jspiders.spring.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.spring.bean.VehicleBean;

public class AppRunner {

	public static void main(String[] args) {
		/*VehicleBean vehicleBean = new VehicleBean();*/
		String configFileName = "context.xml";
		
		ApplicationContext container = new ClassPathXmlApplicationContext(configFileName);
		VehicleBean vehicleBean = container.getBean(VehicleBean.class);
		
		vehicleBean.setVehicleName("RX100");
		
		vehicleBean.ride();
	}
}

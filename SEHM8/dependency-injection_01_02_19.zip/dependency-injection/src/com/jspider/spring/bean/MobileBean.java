package com.jspider.spring.bean;

import java.io.Serializable;

public class MobileBean implements Serializable {
	private BatteryBean batteryBean;
	
	public MobileBean() {
		System.out.println(this.getClass().getSimpleName() + "object created");
	}
	
	public MobileBean(BatteryBean batteryBean) {
		this.batteryBean = batteryBean;
	}

	public BatteryBean getBatteryBean() {
		return batteryBean;
	}
	
	public void setBatteryBean(BatteryBean batteryBean) {
		this.batteryBean = batteryBean;
	}
	
	public void call() {
		batteryBean.supplyPower();
		System.out.println("make Calls with mobile");
	}
	
}

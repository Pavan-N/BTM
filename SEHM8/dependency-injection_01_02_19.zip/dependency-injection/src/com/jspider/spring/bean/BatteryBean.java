package com.jspider.spring.bean;

import java.io.Serializable;

public class BatteryBean implements Serializable {
	
	public BatteryBean() {
		System.out.println(this.getClass().getSimpleName() + "object created");
	}

	public void supplyPower() {
		System.out.println("provide power supply to the device");
	}
	
}

package com.jspiders.spring.bean;

import java.io.Serializable;

public class SuperHeroBean implements Serializable {

	private String name;
	private String superPower;
	private double height;
	private int id;

	public SuperHeroBean() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	public SuperHeroBean(String SuPeRPower, double height, int id) {
		this.superPower = SuPeRPower;
		this.height = height;
		this.id = id;
	}

	/*public SuperHeroBean(String name, String superPower) {
		this.name = name;
		this.superPower = superPower;
	}*/

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSuperPower() {
		return superPower;
	}

	public void setSuperPower(String superPower) {
		this.superPower = superPower;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		System.out.println("Calling setId()");
		this.id = id;
	}

	public void savePublic() {
		System.out.println(this.name + " saving public by using " + this.superPower + " super power");
		System.out.println(this.name + " height: " + this.height);
		System.out.println(this.name + " id: " + this.id);
	}
}

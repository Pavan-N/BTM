package org.jspider.di.bean;

import java.io.Serializable;

public class BrowserBean implements Serializable {

	private String name;
	private double version;
	private InternetBean internet;

	public BrowserBean(InternetBean internetBean) {
		this.internet = internetBean;
		System.out.println(this.getClass().getSimpleName() + " obj created");
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getVersion() {
		return version;
	}

	public void setVersion(double version) {
		this.version = version;
	}

	public InternetBean getInternet() {
		return internet;
	}

	public void setInternet(InternetBean internet) {
		this.internet = internet;
	}

	public void browse() {
		internet.provideServiceOrInternet();
		System.out.println("Browsing internet in " + this.name + " browser of version " + this.version);
	}

	@Override
	public String toString() {
		return "BrowserBean [name=" + name + ", version=" + version + ", internet=" + internet + "]";
	}
	
	

}

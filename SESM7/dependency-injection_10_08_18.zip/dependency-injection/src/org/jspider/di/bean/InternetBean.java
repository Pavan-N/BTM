package org.jspider.di.bean;

import java.io.Serializable;

public class InternetBean implements Serializable {
	private String providerName;
	private double speed;

	public InternetBean(String providename, double speed) {
		this.providerName = providename;
		this.speed = speed;
		System.out.println(this.getClass().getSimpleName() + " obj created");
	}

	public String getProvidename() {
		return providerName;
	}

	public void setProvidename(String providename) {
		this.providerName = providename;
	}

	public double getSpeed() {
		return speed;
	}

	public void setSpeed(double speed) {
		this.speed = speed;
	}

	public void provideServiceOrInternet() {
		System.out.println(this.providerName + " providing internet at a speed of " + this.speed + " kbps/mbps");
	}

	@Override
	public String toString() {
		return "InternetBean [providerName=" + providerName + ", speed=" + speed + "]";
	}
	
	
}

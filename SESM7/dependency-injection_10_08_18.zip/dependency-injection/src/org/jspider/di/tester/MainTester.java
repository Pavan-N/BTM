package org.jspider.di.tester;

import org.jspider.di.bean.BrowserBean;
import org.jspider.di.bean.InternetBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainTester {

	public static void main(String[] args) {
		String ConfigrautionFileName="context.xml";
		ApplicationContext container = new ClassPathXmlApplicationContext(ConfigrautionFileName);
		BrowserBean browserBean = container.getBean(BrowserBean.class);
		browserBean.browse();
		System.out.println(browserBean);
	}

}

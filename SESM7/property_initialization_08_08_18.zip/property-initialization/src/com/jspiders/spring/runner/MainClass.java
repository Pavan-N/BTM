package com.jspiders.spring.runner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.spring.bean.SuperHeroBean;

public class MainClass {

	public static void main(String[] args) {
		String configurationFileName = "context.xml";
		ApplicationContext context = new ClassPathXmlApplicationContext(configurationFileName);
		
		SuperHeroBean superHeroBean = context.getBean(SuperHeroBean.class);
		superHeroBean.savePublic();
	}

}

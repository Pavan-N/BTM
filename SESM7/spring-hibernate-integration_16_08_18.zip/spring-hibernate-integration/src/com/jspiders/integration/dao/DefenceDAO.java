package com.jspiders.integration.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.jspiders.integration.dto.DefenceDTO;

@Repository
public class DefenceDAO {

	@Autowired
	private SessionFactory sessionFactory;
	
	public Integer saveDefence(DefenceDTO defenceDTO) {
		Transaction tx = null;
		Integer identifier = null;
		try(Session session = sessionFactory.openSession()) {
			tx = session.beginTransaction();
			identifier = (Integer) session.save(defenceDTO);
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			tx.rollback();
		}
		return identifier;
	}
}

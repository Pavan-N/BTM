package com.jspiders.integration.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "defence_table")
public class DefenceDTO implements Serializable {

	@Id
	@GenericGenerator(name = "pavan", strategy = "increment")
	@GeneratedValue(generator = "pavan")
	@Column(name = "d_id")
	private int id;
	@Column(name = "country_name")
	private String countryName;
	@Column(name = "no_of_soldiers")
	private double noOfSoldiers;
	@Column(name = "defence_type")
	private String type;
	
	public DefenceDTO() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public double getNoOfSoldiers() {
		return noOfSoldiers;
	}

	public void setNoOfSoldiers(double noOfSoldiers) {
		this.noOfSoldiers = noOfSoldiers;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}

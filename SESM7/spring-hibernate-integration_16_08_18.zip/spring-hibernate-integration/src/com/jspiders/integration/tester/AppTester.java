package com.jspiders.integration.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.integration.dao.DefenceDAO;
import com.jspiders.integration.dto.DefenceDTO;

public class AppTester {

	public static void main(String[] args) {
		DefenceDTO defenceDTO = new DefenceDTO();
		defenceDTO.setCountryName("India");
		defenceDTO.setNoOfSoldiers(1000000);
		defenceDTO.setType("Army & Navy & AirForce");
		
		ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
		DefenceDAO defenceDAO = context.getBean(DefenceDAO.class);
		Integer defenceId = defenceDAO.saveDefence(defenceDTO);
		
		System.out.println("Defence object saved with Id: "+ defenceId);
		
	}

}

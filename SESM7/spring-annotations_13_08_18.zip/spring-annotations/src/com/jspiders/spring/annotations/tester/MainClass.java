package com.jspiders.spring.annotations.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.spring.annotations.bean.EducationBean;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
		
		EducationBean educationBean = context.getBean(EducationBean.class);
		educationBean.getKnowledge();

	}

}

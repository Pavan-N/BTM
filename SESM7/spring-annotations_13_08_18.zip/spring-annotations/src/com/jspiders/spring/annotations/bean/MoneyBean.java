package com.jspiders.spring.annotations.bean;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class MoneyBean implements Serializable{

	
	private String modeOfTransaction;
	
	@Autowired
	public MoneyBean(@Value("online") String modeOfTransaction) {
		this.modeOfTransaction = modeOfTransaction;
	}

	public String getModeOfTransaction() {
		return modeOfTransaction;
	}

	public void setModeOfTransaction(String modeOfTransaction) {
		this.modeOfTransaction = modeOfTransaction;
	}
	
	public void emptyPocketsAndAccounts() {
		System.out.println("Transacting " + modeOfTransaction);
		System.out.println("No money");
	}

}

package com.jspiders.spring.annotations.bean;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class EducationBean implements Serializable {

	@Value("Java")
	private String course;
	private double duration;

	private MoneyBean money;

	@Autowired
	public EducationBean(MoneyBean money) {
		this.money = money;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public double getDuration() {
		return duration;
	}

	@Value("1.5")
	public void setDuration(double duration) {
		this.duration = duration;
	}

	public MoneyBean getMoney() {
		return money;
	}

	public void setMoney(MoneyBean money) {
		this.money = money;
	}

	public void getKnowledge() {
		money.emptyPocketsAndAccounts();
		System.out.println("Course name: " + this.course);
		System.out.println("Course duration: " + this.duration);
	}

}

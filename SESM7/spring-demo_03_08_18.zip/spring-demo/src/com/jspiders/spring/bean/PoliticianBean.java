package com.jspiders.spring.bean;

import java.io.Serializable;

public class PoliticianBean implements Serializable {

	private String name;
	private String party;
	private double age;

	public PoliticianBean() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getParty() {
		return party;
	}

	public void setParty(String party) {
		this.party = party;
	}

	public double getAge() {
		return age;
	}

	public void setAge(double age) {
		this.age = age;
	}

	
}

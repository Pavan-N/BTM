package com.jspiders.spring.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.spring.bean.PoliticianBean;

public class AppTester {

	public static void main(String[] args) {
		/*PoliticianBean politicianBean = new PoliticianBean();
		politicianBean.corrutpion();*/
		
		ApplicationContext container = new ClassPathXmlApplicationContext("context.xml");
		PoliticianBean politicianBean = container.getBean(PoliticianBean.class);
		politicianBean.corrutpion();

	}

}

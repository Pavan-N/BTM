package org.sam.spring.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.sam.spring.dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ResgistrationDAO {

	@Autowired
	private SessionFactory factory;
	
	public Integer saveUser(UserDTO userDTO) {
		Integer identifier = null;
		Transaction tx = null;
		try(Session session = factory.openSession()) {
			tx = session.beginTransaction();
			identifier = (Integer) session.save(userDTO);
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			tx.rollback();
		}
		return identifier;
	}
}

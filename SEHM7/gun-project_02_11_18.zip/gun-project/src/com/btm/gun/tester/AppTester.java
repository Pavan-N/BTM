package com.btm.gun.tester;

import java.util.List;

import com.btm.gun.dao.GunDao;
import com.btm.gun.dto.GunDTO;

public class AppTester {

	public static void main(String[] args) {
		/*GunDTO gunDTO = new GunDTO();
		gunDTO.setGunName("AK47");
		gunDTO.setRange(3000);
		gunDTO.setRate(7823597l);
		gunDTO.setType("Rifle");*/
		
		GunDao gunDao = new GunDao();
		/*Integer identifier = gunDao.saveGun(gunDTO);
		System.out.println("Gun saved with id: " + identifier);*/
		
		/*String gunType = gunDao.getGunTypeByName("AK47");
		System.out.println("Gun Type: " + gunType);*/
		
		System.out.println("-----------------------------------------------------------------");
		
		/*GunDTO gunDTO = gunDao.getGunByName("AK47");
		if (gunDTO != null) {
			System.out.println(gunDTO.getType());
			System.out.println(gunDTO.getRange());
		}*/
		
		/*int recordsUpdated = gunDao.updateGunRateByType("Rifle", 12345678l);
		System.out.println("Records updated: " + recordsUpdated);*/
		
		/*List<Double> listOfGunRanges = gunDao.getGunRange();
		for (Double range : listOfGunRanges) {
			System.out.println(range);
			System.out.println("*******************************************s");
		}*/
		
		List<GunDTO> listOfGuns = gunDao.getAllGunData();
		for (GunDTO gunDTO : listOfGuns) {
			if (gunDTO != null) {
				System.out.println("*******************************************");
				System.out.println(gunDTO.getGunName());
				System.out.println(gunDTO.getType());
				System.out.println(gunDTO.getRange());
			}
		}
	}

}

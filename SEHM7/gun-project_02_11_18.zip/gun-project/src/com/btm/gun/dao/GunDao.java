package com.btm.gun.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.btm.gun.dto.GunDTO;
import com.jspiders.hibernate.util.HibernateUtil;

public class GunDao {

	private SessionFactory factory = HibernateUtil.getSessionFactory();

	public Integer saveGun(GunDTO dto) {
		Transaction tx = null;
		Session session = null;
		Integer identifier = null;
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			identifier = (Integer) session.save(dto);
			tx.commit();
		} catch (HibernateException he) {
			he.printStackTrace();
			tx.rollback();
		} finally {
			session.close();
		}
		return identifier;
	}

	public String getGunTypeByName(String gunName) {
		String gunType = null;
		String hql = "SELECT gun.type FROM GunDTO gun WHERE gun.gunName=:name";
		try(Session session = factory.openSession()) {
			Query query = session.createQuery(hql);
			query.setParameter("name", gunName);
			gunType = (String) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return gunType;
	}
	
	public GunDTO getGunByName(String gunName) {
		GunDTO gunDTO = null;
		String hql = "SELECT gun FROM GunDTO gun WHERE gun.gunName=:name";
		try(Session session = factory.openSession()) {
			Query query = session.createQuery(hql);
			query.setParameter("name", gunName);
			gunDTO = (GunDTO) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return gunDTO;
	}
	
	public int updateGunRateByType(String gunType, long gunRate) {
		int noOfRecordsUpdated = 0;
		Transaction tx = null;
		String hql = "UPDATE GunDTO gun SET gun.rate=:gRate WHERE gun.type=:gType";
		try(Session session = factory.openSession()) {
			tx = session.beginTransaction();
			Query query = session.createQuery(hql);
			query.setParameter("gType", gunType);
			query.setParameter("gRate", gunRate);
			noOfRecordsUpdated = query.executeUpdate();
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			tx.rollback();
		}
		return noOfRecordsUpdated;
	}
	
	public List getGunRange() {
		List<Double> gunRanges = null;
		String hql = "SELECT gun.range FROM GunDTO gun";
		try(Session session = factory.openSession()) {
			Query query = session.createQuery(hql);
			gunRanges = query.list();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return gunRanges;
	}
	
	public List<GunDTO> getAllGunData() {
		List<GunDTO> guns = null;
		String hql = "SELECT gun FROM GunDTO gun";
		try(Session session = factory.openSession()) {
			Query query = session.createQuery(hql);
			guns = query.list();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return guns;
	}
	
	
	
	
	
	
}

package com.jspiders.hibernate.tester;

import com.jspiders.hibernate.dao.PubDAO;
import com.jspiders.hibernate.dto.PubDTO;

public class MainClass {

	public static void main(String[] args) {
		PubDTO pubDTO = new PubDTO();
		
		pubDTO.setPubId(2);
		pubDTO.setPubName("Jspiders");
		pubDTO.setEntryFee(999.99);
		pubDTO.setEntryType(1);
		pubDTO.setDrinkType("WATER");

		PubDAO dao = new PubDAO();
		
		dao.savePub(pubDTO);
	}

}

package com.jspiders.integration.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.integration.dao.PayTmDAO;
import com.jspiders.integration.dto.PayTmDTO;

public class AppTester {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
		
		PayTmDTO payTmDTO = new PayTmDTO();
		payTmDTO.setAccountUserName("Jspiders");
		payTmDTO.setNoOfTransactions(500);
		payTmDTO.setWalletBalance(200000);
		
		
		PayTmDAO payTmDAO = context.getBean(PayTmDAO.class);
		payTmDAO.savePayTm(payTmDTO);

	}

}

package com.jspiders.integration.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "paytm_table")
public class PayTmDTO implements Serializable {

	@Id
	@GenericGenerator(name = "auto", strategy = "increment")
	@GeneratedValue(generator = "auto")
	@Column(name = "paytm_user_id")
	private int pUserId;
	@Column(name = "wallet_balance")
	private double walletBalance;
	@Column(name = "account_user_name")
	private String accountUserName;
	@Column(name = "no_of_transactions")
	private int noOfTransactions;

	public PayTmDTO() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	public int getpUserId() {
		return pUserId;
	}

	public void setpUserId(int pUserId) {
		this.pUserId = pUserId;
	}

	public double getWalletBalance() {
		return walletBalance;
	}

	public void setWalletBalance(double walletBalance) {
		this.walletBalance = walletBalance;
	}

	public String getAccountUserName() {
		return accountUserName;
	}

	public void setAccountUserName(String accountUserName) {
		this.accountUserName = accountUserName;
	}

	public int getNoOfTransactions() {
		return noOfTransactions;
	}

	public void setNoOfTransactions(int noOfTransactions) {
		this.noOfTransactions = noOfTransactions;
	}
}

package com.jspiders.spring.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.spring.bean.MicrophoneBean;

public class AppTester {

	public static void main(String[] args) {
		String configFileName = "context.xml";
		
		ApplicationContext context = new ClassPathXmlApplicationContext(configFileName);
		
		MicrophoneBean microphoneBean = context.getBean(MicrophoneBean.class);
		microphoneBean.passVoice();
		
		System.out.println("Mic Brand: " + microphoneBean.getBrand());
		System.out.println("Mic Price: " + microphoneBean.getPrice());
	}

}

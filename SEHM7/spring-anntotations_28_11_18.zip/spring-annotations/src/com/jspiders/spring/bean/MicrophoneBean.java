package com.jspiders.spring.bean;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
//@Scope(value = "singleton")
public class MicrophoneBean implements Serializable {

	@Value("Sony")
	private String brand;
	private double price;
	//@Autowired
	private SpeakerBean speaker;
	
	public MicrophoneBean() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	@Autowired
	public MicrophoneBean(SpeakerBean speaker) {
		super();
		this.speaker = speaker;
	}

	/*@Autowired
	public MicrophoneBean(@Value("Sony") String brand,@Value("345.23") double price) {
		this.brand = brand;
		this.price = price;
	}*/
	
	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public double getPrice() {
		return price;
	}

	@Value(value = "300.78")
	public void setPrice(double price) {
		this.price = price;
	}
	
	public SpeakerBean getSpeaker() {
		return speaker;
	}

	//@Autowired
	public void setSpeaker(SpeakerBean speaker) {
		this.speaker = speaker;
	}

	public void passVoice() {
		System.out.println("Listening to sound");
		speaker.provideSound();
	}

}

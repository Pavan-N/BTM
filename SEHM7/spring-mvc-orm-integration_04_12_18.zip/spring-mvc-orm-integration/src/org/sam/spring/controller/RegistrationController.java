package org.sam.spring.controller;

import javax.servlet.http.HttpServletRequest;

import org.sam.spring.dto.UserDTO;
import org.sam.spring.service.RegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RegistrationController 
{
	/*@GetMapping("/reg.do")
	public String registerUser(HttpServletRequest req)
	{
		String userName=req.getParameter("username");
		String mobile=req.getParameter("mobileNumber");
		Long mobileNumber=Long.parseLong(mobile);
		
		System.out.println(userName);
		System.out.println(mobileNumber);
		return "success.jsp";
		
		
	}*/
	
	@Autowired
	private RegistrationService registrationService;
	
	@PostMapping("/reg.do")
	public ModelAndView registerUser(@RequestParam String username, @RequestParam String password, @RequestParam Long mobileNumber) {
		UserDTO userDTO = new UserDTO();
		userDTO.setUserName(username);
		userDTO.setMobileNumber(mobileNumber);
		userDTO.setPassword(password);
		
		boolean operationStatus = registrationService.register(userDTO);
		
		if (operationStatus) { 
			return new ModelAndView("success.jsp");
		}
		else {
			return new ModelAndView("failure.jsp");

		}
	}
	
}

package org.sam.spring.service;

import org.sam.spring.dao.ResgistrationDAO;
import org.sam.spring.dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegistrationService {
	
	@Autowired
	private ResgistrationDAO resgistrationDAO;

	public boolean register(UserDTO userDTO) {
		Integer identifier = resgistrationDAO.saveUser(userDTO);
		if (identifier != null && identifier > 0) {
			return true;
		} else {
			return false;
		}
	}
}

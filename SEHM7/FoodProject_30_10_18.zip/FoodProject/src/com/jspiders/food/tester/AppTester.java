package com.jspiders.food.tester;

import com.jspiders.food.dao.FoodDAO;
import com.jspiders.food.dto.FoodDTO;

public class AppTester {

	public static void main(String[] args) {
		/*FoodDTO foodDTO = new FoodDTO();
		
		foodDTO.setFoodID(1);
		foodDTO.setFoodName("VadaPav");
		foodDTO.setFoodType("Veg");
		foodDTO.setQuantity(150);
		foodDTO.setPrice(50.70);*/

		FoodDAO foodDAO = new FoodDAO();
		//foodDAO.saveFood(foodDTO);
		
		/*FoodDTO foodDTO = foodDAO.getFoodById(1);
		System.out.println("food name: " + foodDTO.getFoodName());
		System.out.println("food type: " + foodDTO.getFoodType());*/
		
		foodDAO.updateFoodPriceById(45.78, 1);
		
		
		
	}

}

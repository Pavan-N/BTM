package com.btm.gun.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="gun_table")
public class GunDTO implements Serializable{
	@GenericGenerator(name = "auto", strategy = "increment")
	@GeneratedValue(generator="auto")
	@Id
	@Column(name="gun_id")
	private int gunId;
	@Column(name="gun_name")
	private String gunName;
	@Column(name="gun_rate")
	private long rate;
	@Column(name="gun_type")
	private String type;
	@Column(name="gun_range")
	private double range;

	public GunDTO() {
		System.out.println(this.getClass().getSimpleName() + "Object has created.");
	}

	public int getGunId() {
		return gunId;
	}

	public void setGunId(int gunId) {
		this.gunId = gunId;
	}

	public String getGunName() {
		return gunName;
	}

	public void setGunName(String gunName) {
		this.gunName = gunName;
	}

	public long getRate() {
		return rate;
	}

	public void setRate(long rate) {
		this.rate = rate;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getRange() {
		return range;
	}

	public void setRange(double range) {
		this.range = range;
	}

}

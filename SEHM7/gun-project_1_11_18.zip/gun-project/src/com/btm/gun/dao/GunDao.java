package com.btm.gun.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.btm.gun.dto.GunDTO;
import com.jspiders.hibernate.util.HibernateUtil;

public class GunDao {

	private SessionFactory factory = HibernateUtil.getSessionFactory();

	public Integer saveGun(GunDTO dto) {
		Transaction tx = null;
		Session session = null;
		Integer identifier = null;
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			identifier = (Integer) session.save(dto);
			tx.commit();
		} catch (HibernateException he) {
			he.printStackTrace();
			tx.rollback();
		} finally {
			session.close();
		}
		return identifier;
	}

	public String getGunTypeByName(String gunName) {
		String gunType = null;
		String hql = "SELECT gun.type FROM GunDTO gun WHERE gun.gunName=:name";
		try(Session session = factory.openSession()) {
			Query query = session.createQuery(hql);
			query.setParameter("name", gunName);
			gunType = (String) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return gunType;
	}
	
	public GunDTO getGunByName(String gunName) {
		GunDTO gunDTO = null;
		String hql = "SELECT gun FROM GunDTO gun WHERE gun.gunName=:name";
		try(Session session = factory.openSession()) {
			Query query = session.createQuery(hql);
			query.setParameter("name", gunName);
			gunDTO = (GunDTO) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return gunDTO;
	}
	
	
	
	
	
	
	
}

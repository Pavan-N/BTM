package com.jspiders.hibernate.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "earth_table")
public class EarthDTO implements Serializable {
	public EarthDTO() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	@Id
	@GenericGenerator(name = "jspider", strategy = "increment")
	@GeneratedValue(generator = "jspider")
	@Column(name= "e_id")
	private int earthId;
	@Column(name = "e_size")
	private double size;
	@Column(name = "e_shape")
	private String shape;

	public int getEarthId() {
		return earthId;
	}

	public void setEarthId(int earthId) {
		this.earthId = earthId;
	}

	public double getSize() {
		return size;
	}

	public void setSize(double size) {
		this.size = size;
	}

	public String getShape() {
		return shape;
	}

	public void setShape(String shape) {
		this.shape = shape;
	}

	@Override
	public String toString() {
		return "EarthDTO [earthId=" + earthId + ", size=" + size + ", shape="
				+ shape + "]";
	}
	
}

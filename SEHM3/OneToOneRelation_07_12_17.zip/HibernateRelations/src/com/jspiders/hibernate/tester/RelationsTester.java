package com.jspiders.hibernate.tester;

import com.jspiders.hibernate.dao.MoonDAO;
import com.jspiders.hibernate.dto.EarthDTO;
import com.jspiders.hibernate.dto.MoonDTO;

public class RelationsTester {

	public static void main(String[] args) {
		/*EarthDTO earthDTO = new EarthDTO();
		//earthDTO.setEarthId(1);
		earthDTO.setShape("flat");
		earthDTO.setSize(1123.12);
		
		MoonDTO moonDTO = new MoonDTO();
		//moonDTO.setMoonId(1);
		moonDTO.setTemperature(-100.50);
		moonDTO.setColour("SomeColour");
		
		moonDTO.setEarth(earthDTO);

		System.out.println(moonDTO);*/
		
		MoonDAO dao = new MoonDAO();
		//dao.saveMoon(moonDTO);
		MoonDTO moonDTO = dao.getMoon(1);
		System.out.println(moonDTO);
	}

}

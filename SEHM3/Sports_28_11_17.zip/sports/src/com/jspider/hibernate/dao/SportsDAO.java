package com.jspider.hibernate.dao;


import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.jspider.hibernate.dto.SportsDTO;
import com.jspiders.hibernate.util.HibernateUtil;

public class SportsDAO {

	public void saveSports(SportsDTO dto)
	{
		Session session=null;
		Transaction transaction=null;
		SessionFactory factory=HibernateUtil.getSessionFactory();
		try {
			 session= factory.openSession();
			 transaction= session.beginTransaction();
			 session.save(dto);
			 transaction.commit();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			transaction.rollback();
		}
		finally
		{
			if(session!=null)
			session.close();
			
		}
		
		
		
		
		
		
		
		
	}
}

package com.jspider.hibernate.tester;

import com.jspider.hibernate.dao.SportsDAO;
import com.jspider.hibernate.dto.SportsDTO;

public class AppTester {
public static void main(String[] args) {
	SportsDTO dto=new SportsDTO();
	dto.setName("cricket");
	dto.setNoOfPlayers(15);
	dto.setType("indoor");
	SportsDAO dao=new SportsDAO();
	dao.saveSports(dto);
}
}

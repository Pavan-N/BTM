package com.jspider.hibernate.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="sports_table")
public class SportsDTO implements Serializable{
public SportsDTO(){
	System.out.println(this.getClass().getSimpleName()+" is created");
}
@Id
@GenericGenerator(name = "auto", strategy = "increment")
@GeneratedValue(generator = "auto")
@Column(name="s_id")
private int id;
@Column(name="s_type")
private String type;
@Column(name="s_name")
private String name;
@Column(name="s_no_of_players")
private int noOfPlayers;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getNoOfPlayers() {
	return noOfPlayers;
}
public void setNoOfPlayers(int noOfPlayers) {
	this.noOfPlayers = noOfPlayers;
}


}

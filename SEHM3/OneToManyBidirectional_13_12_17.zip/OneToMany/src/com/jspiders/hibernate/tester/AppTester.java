package com.jspiders.hibernate.tester;

import java.util.ArrayList;
import java.util.List;

import com.jspiders.hibernate.dao.BoardDAO;
import com.jspiders.hibernate.dao.IccDAO;
import com.jspiders.hibernate.dto.CricketBoardDTO;
import com.jspiders.hibernate.dto.IccDTO;

public class AppTester {

	public static void main(String[] args) {
		IccDTO iccDTO = new IccDTO();
		iccDTO.setHeadQuarters("Dubai");
		iccDTO.setNoOfBoards(12);
		
		CricketBoardDTO cricket1 = new CricketBoardDTO();
		cricket1.setName("BCCI");
		
		CricketBoardDTO cricket2 = new CricketBoardDTO();
		cricket2.setName("PCB");
		
		CricketBoardDTO cricket3 = new CricketBoardDTO();
		cricket3.setName("SCI");
		
		//relating
		cricket1.setIcc(iccDTO);
		cricket2.setIcc(iccDTO);
		cricket3.setIcc(iccDTO);
		
		List<CricketBoardDTO> listOfCricketBoards = new ArrayList<CricketBoardDTO>();
		listOfCricketBoards.add(cricket1);
		listOfCricketBoards.add(cricket2);
		listOfCricketBoards.add(cricket3);
		
		iccDTO.setCricketBoards(listOfCricketBoards);

		/*BoardDAO dao = new BoardDAO();
		dao.saveCricketBoard(cricket);*/
		
		IccDAO iccDao = new IccDAO();
		iccDao.saveIcc(iccDTO);
	}

}

package com.jspiders.hibernate.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.jspiders.hibernate.dto.CricketBoardDTO;
import com.jspiders.hibernate.util.HibernateUtil;

public class BoardDAO {

	public void saveCricketBoard(CricketBoardDTO dto) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		session.save(dto);
		tx.commit();
		session.close();
	}
}

package com.jspiders.hibernate.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.jspiders.hibernate.dto.IccDTO;
import com.jspiders.hibernate.util.HibernateUtil;

public class IccDAO {

	public void saveIcc(IccDTO dto) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		session.save(dto);
		tx.commit();
		session.close();
	}
}

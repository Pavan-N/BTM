package com.jspiders.hibernate.dto;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "icc_table")
public class IccDTO implements Serializable {

	@Id
	@GenericGenerator(name = "auto", strategy = "increment")
	@GeneratedValue(generator = "auto")
	@Column(name = "icc_id")
	private int id;
	@Column(name = "head_quarters")
	private String headQuarters;
	@Column(name = "no_of_boards")
	private int noOfBoards;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "icc")
	private List<CricketBoardDTO> cricketBoards;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getHeadQuarters() {
		return headQuarters;
	}

	public void setHeadQuarters(String headQuarters) {
		this.headQuarters = headQuarters;
	}

	public int getNoOfBoards() {
		return noOfBoards;
	}

	public void setNoOfBoards(int noOfBoards) {
		this.noOfBoards = noOfBoards;
	}

	public List<CricketBoardDTO> getCricketBoards() {
		return cricketBoards;
	}

	public void setCricketBoards(List<CricketBoardDTO> cricketBoards) {
		this.cricketBoards = cricketBoards;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((cricketBoards == null) ? 0 : cricketBoards.hashCode());
		result = prime * result
				+ ((headQuarters == null) ? 0 : headQuarters.hashCode());
		result = prime * result + id;
		result = prime * result + noOfBoards;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		IccDTO other = (IccDTO) obj;
		if (cricketBoards == null) {
			if (other.cricketBoards != null)
				return false;
		} else if (!cricketBoards.equals(other.cricketBoards))
			return false;
		if (headQuarters == null) {
			if (other.headQuarters != null)
				return false;
		} else if (!headQuarters.equals(other.headQuarters))
			return false;
		if (id != other.id)
			return false;
		if (noOfBoards != other.noOfBoards)
			return false;
		return true;
	}

}

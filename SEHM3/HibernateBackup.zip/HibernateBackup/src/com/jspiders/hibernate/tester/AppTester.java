package com.jspiders.hibernate.tester;

import com.jspiders.hibernate.dao.BankDAO;
import com.jspiders.hibernate.dto.BankDTO;

public class AppTester {

	public static void main(String[] args) {
		BankDTO bankDTO = new BankDTO();
		bankDTO.setBankId(4);
		bankDTO.setName("ICICI");
		bankDTO.setBranch("BTM");
		bankDTO.setNoOfAccounts(100);
		
		BankDAO dao = new BankDAO();
		dao.saveBank(bankDTO);
		//BankDTO bankDTO = dao.getBankById(2);
		//System.out.println(bankDTO);
		//dao.updateBankById(6);
		
		
		
	}

}

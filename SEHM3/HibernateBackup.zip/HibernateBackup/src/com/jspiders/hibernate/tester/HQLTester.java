package com.jspiders.hibernate.tester;

import com.jspiders.hibernate.dao.BankHQLDAO;

public class HQLTester {

	public static void main(String[] args) {
		BankHQLDAO dao = new BankHQLDAO();
		dao.updateNoOfAccontsByName();
	}

}

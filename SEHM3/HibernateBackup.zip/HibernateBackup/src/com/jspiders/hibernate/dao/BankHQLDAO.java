package com.jspiders.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.jspiders.hibernate.util.HibernateUtil;

public class BankHQLDAO {

	public void updateNoOfAccontsByName() {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = null;
		Transaction tx = null;
		String hql = "UPDATE BankDTO bank SET bank.noOfAccounts = 150 WHERE bank.name = 'ICICI'";
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			//Step 1: prepare the query
			Query query = session.createQuery(hql);
			
			//Step 2: process/execute the query
			query.executeUpdate();
			
			tx.commit();
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
}

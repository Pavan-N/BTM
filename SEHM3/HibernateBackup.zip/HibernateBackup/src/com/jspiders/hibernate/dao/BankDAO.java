package com.jspiders.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.jspiders.hibernate.dto.BankDTO;
import com.jspiders.hibernate.util.HibernateUtil;

public class BankDAO {

	public void saveBank(BankDTO dto) {
		/*
		 * //component 1 Configuration cfg = new Configuration();
		 * cfg.configure();
		 * 
		 * //component 2 SessionFactory factory = cfg.buildSessionFactory();
		 */
		SessionFactory factory = null;
		Session session = null;
		Transaction tx = null;
		try {
			factory = HibernateUtil.getSessionFactory();

			// component 3
			session = factory.openSession();

			// sub-component 1 of session
			tx = session.beginTransaction();

			session.save(dto);

			tx.commit();
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	public BankDTO getBankById(int primaryKey) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = null;
		BankDTO bankDTO = null;
		try {
			session = factory.openSession();
			bankDTO = session.get(BankDTO.class, new Integer(primaryKey));
		} catch (HibernateException e) {
 			e.printStackTrace();
		} finally {
			session.close();
		}
		return bankDTO;
	}
	
	public void updateBankById(int primaryKey) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = null;
		Transaction tx = null;
		BankDTO bankDTO = null;
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			bankDTO = session.get(BankDTO.class, new Integer(primaryKey));
			bankDTO.setName("HDFC");
			session.update(bankDTO);
			tx.commit();
		} catch (HibernateException e) {
 			e.printStackTrace();
 			tx.rollback();
		} finally {
			session.close();
		}
	}
	
	
	
	
	
	
	
}

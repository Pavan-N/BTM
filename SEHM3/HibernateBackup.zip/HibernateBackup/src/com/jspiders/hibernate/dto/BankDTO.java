package com.jspiders.hibernate.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name= "bank_table")
public class BankDTO implements Serializable {
	@Id
	@GenericGenerator(name = "pavan", strategy = "increment")
	@GeneratedValue(generator = "pavan")
	@Column(name = "b_id")
	private int bankId;
	@Column(name = "b_name")
	private String name;
	@Column(name = "b_branch")
	private String branch;
	@Column(name = "no_of_accounts")
	private long noOfAccounts;

	public BankDTO() {
		System.out.println(this.getClass().getSimpleName() + " Created");
	}
	
	public int getBankId() {
		return bankId;
	}

	public void setBankId(int bankId) {
		this.bankId = bankId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public long getNoOfAccounts() {
		return noOfAccounts;
	}

	public void setNoOfAccounts(long noOfAccounts) {
		this.noOfAccounts = noOfAccounts;
	}

	@Override
	public String toString() {
		return "BankDTO [bankId=" + bankId + ", name=" + name + ", branch="
				+ branch + ", noOfAccounts=" + noOfAccounts + "]";
	}

}

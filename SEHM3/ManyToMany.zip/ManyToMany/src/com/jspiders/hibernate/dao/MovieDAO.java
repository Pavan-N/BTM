package com.jspiders.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.jspiders.hibernate.dto.MovieDTO;
import com.jspiders.hibernate.util.HibernateUtil;

public class MovieDAO {

	public MovieDTO getMovieByName(String movieName) {
		Session session = null;
		MovieDTO dto = null;
		String hql = "SELECT movie FROM MovieDTO movie WHERE movie.name=:mName";
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			Query query = session.createQuery(hql);
			query.setParameter("mName", movieName);
			dto = (MovieDTO) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return dto;
	}

	public void saveMovie(MovieDTO movieDTO) {
		Session session = null;
		Transaction tx = null;
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			tx = session.beginTransaction();
			session.save(movieDTO);
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			session.close();
		}
	}
}

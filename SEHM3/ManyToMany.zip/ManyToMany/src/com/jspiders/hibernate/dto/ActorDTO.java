package com.jspiders.hibernate.dto;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "actor_table")
public class ActorDTO implements Serializable {
	@Id
	@GenericGenerator(name = "auto", strategy = "increment")
	@GeneratedValue(generator = "auto")
	@Column(name = "a_id")
	private int actorId;
	@Column(name = "a_name")
	private String name;
	@Column(name = "a_payment")
	private double payment;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "movie_actor_table", 
				joinColumns = { @JoinColumn(name = "actor_id") }, 
				inverseJoinColumns = { @JoinColumn(name = "movie_id") })
	private List<MovieDTO> movies;

	public int getActorId() {
		return actorId;
	}

	public void setActorId(int actorId) {
		this.actorId = actorId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPayment() {
		return payment;
	}

	public void setPayment(double payment) {
		this.payment = payment;
	}

	public List<MovieDTO> getMovies() {
		return movies;
	}

	public void setMovies(List<MovieDTO> movies) {
		this.movies = movies;
	}

	@Override
	public String toString() {
		return "ActorDTO [actorId=" + actorId + ", name=" + name + ", payment="
				+ payment + ", movies=" + movies + "]";
	}

}

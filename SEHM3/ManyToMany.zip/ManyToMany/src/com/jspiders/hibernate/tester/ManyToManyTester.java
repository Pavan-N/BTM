package com.jspiders.hibernate.tester;

import java.util.ArrayList;
import java.util.List;

import com.jspiders.hibernate.dao.ActorDAO;
import com.jspiders.hibernate.dao.MovieDAO;
import com.jspiders.hibernate.dto.ActorDTO;
import com.jspiders.hibernate.dto.MovieDTO;

public class ManyToManyTester {

	public static void main(String[] args) {
		/*MovieDTO movie1 = new MovieDTO();
		movie1.setName("Chamak");
		movie1.setLanguage("Kannada");
		movie1.setBudget(50000000);
		
		MovieDTO movie2 = new MovieDTO();
		movie2.setName("Tiger Zinda Hai");
		movie2.setLanguage("Hindi");
		movie2.setBudget(1500000000);
		
		MovieDTO movie3 = new MovieDTO();
		movie3.setName("Bahubali2");
		movie3.setLanguage("Telugu");
		movie3.setBudget(2000000000);
		
		ActorDTO actorDTO = new ActorDTO();
		actorDTO.setName("Rajnikanth");
		actorDTO.setPayment(1400000000);
		
		List<MovieDTO> listOfMovies = new ArrayList<MovieDTO>();
		listOfMovies.add(movie1);
		listOfMovies.add(movie2);
		listOfMovies.add(movie3);
		
		actorDTO.setMovies(listOfMovies);
		
		System.out.println(actorDTO);
		
		ActorDAO dao = new ActorDAO();
		dao.saveActor(actorDTO);*/
		
		MovieDAO dao = new MovieDAO();
		MovieDTO movieDTO = dao.getMovieByName("Bahubali2");
		
		List<MovieDTO> movieList = new ArrayList<MovieDTO>();
		movieList.add(movieDTO);
		
		List<ActorDTO> listOfActors = new ArrayList<ActorDTO>();
		
		ActorDTO actor1 = new ActorDTO();
		actor1.setName("Prabhas");
		actor1.setPayment(35000000);
		actor1.setMovies(movieList);
		
		ActorDTO actor2 = new ActorDTO();
		actor2.setName("Kattappa");
		actor2.setPayment(2345678);
		actor2.setMovies(movieList);
		
		ActorDTO actor3 = new ActorDTO();
		actor3.setName("AnushkaShetty");
		actor3.setPayment(23456789);
		actor3.setMovies(movieList);
		
		ActorDTO actor4 = new ActorDTO();
		actor4.setName("Tamanna");
		actor4.setPayment(34567);
		actor4.setMovies(movieList);

		listOfActors.add(actor1);
		listOfActors.add(actor2);
		listOfActors.add(actor3);
		listOfActors.add(actor4);
		movieDTO.setActors(listOfActors);
		
		dao.saveMovie(movieDTO);
	}

}

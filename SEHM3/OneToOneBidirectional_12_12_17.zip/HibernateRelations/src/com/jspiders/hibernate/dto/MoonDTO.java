package com.jspiders.hibernate.dto;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "moon_table")
public class MoonDTO implements Serializable {
	public MoonDTO() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	@Id
	@GenericGenerator(name = "jspider", strategy = "increment")
	@GeneratedValue(generator = "jspider")
	@Column(name = "m_id")
	private int moonId;
	@Column(name = "m_temp")
	private double temperature;
	@Column(name = "colour")
	private String colour;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "earth_id")
	private EarthDTO earth;

	public int getMoonId() {
		return moonId;
	}

	public void setMoonId(int moonId) {
		this.moonId = moonId;
	}

	public double getTemperature() {
		return temperature;
	}

	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public EarthDTO getEarth() {
		return earth;
	}

	public void setEarth(EarthDTO earth) {
		this.earth = earth;
	}

	@Override
	public String toString() {
		return "MoonDTO [moonId=" + moonId + ", temperature=" + temperature
				+ ", colour=" + colour + ", earth=" + earth + "]";
	}

}

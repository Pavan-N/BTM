package com.jspiders.hibernate.dto;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "earth_table")
public class EarthDTO implements Serializable {
	public EarthDTO() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	@Id
	@GenericGenerator(name = "jspider", strategy = "increment")
	@GeneratedValue(generator = "jspider")
	@Column(name= "e_id")
	private int earthId;
	@Column(name = "e_size")
	private double size;
	@Column(name = "e_shape")
	private String shape;
	
	@OneToOne(cascade = CascadeType.ALL, mappedBy = "earth")
	private MoonDTO moon;

	public int getEarthId() {
		return earthId;
	}

	public void setEarthId(int earthId) {
		this.earthId = earthId;
	}

	public double getSize() {
		return size;
	}

	public void setSize(double size) {
		this.size = size;
	}

	public String getShape() {
		return shape;
	}

	public void setShape(String shape) {
		this.shape = shape;
	}

	public MoonDTO getMoon() {
		return moon;
	}

	public void setMoon(MoonDTO moon) {
		this.moon = moon;
	}

	@Override
	public String toString() {
		return "EarthDTO [earthId=" + earthId + ", size=" + size + ", shape="
				+ shape + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + earthId;
		result = prime * result + ((moon == null) ? 0 : moon.hashCode());
		result = prime * result + ((shape == null) ? 0 : shape.hashCode());
		long temp;
		temp = Double.doubleToLongBits(size);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EarthDTO other = (EarthDTO) obj;
		if (earthId != other.earthId)
			return false;
		if (moon == null) {
			if (other.moon != null)
				return false;
		} else if (!moon.equals(other.moon))
			return false;
		if (shape == null) {
			if (other.shape != null)
				return false;
		} else if (!shape.equals(other.shape))
			return false;
		if (Double.doubleToLongBits(size) != Double
				.doubleToLongBits(other.size))
			return false;
		return true;
	}
	
}

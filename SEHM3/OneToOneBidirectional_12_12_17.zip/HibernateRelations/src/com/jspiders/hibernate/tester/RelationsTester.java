package com.jspiders.hibernate.tester;

import com.jspiders.hibernate.dao.MoonDAO;
import com.jspiders.hibernate.dto.EarthDTO;
import com.jspiders.hibernate.dto.MoonDTO;

public class RelationsTester {

	public static void main(String[] args) {
		EarthDTO earthDTO = new EarthDTO();
		earthDTO.setShape("spherical");
		earthDTO.setSize(1123.12);
		
		MoonDTO moonDTO = new MoonDTO();
		moonDTO.setTemperature(-135.53);
		moonDTO.setColour("White");
		
		moonDTO.setEarth(earthDTO);
		earthDTO.setMoon(moonDTO);
		
		MoonDAO dao = new MoonDAO();
		//dao.saveMoon(moonDTO);
		
		MoonDTO moon = dao.getMoon(2);
		EarthDTO earth = moon.getEarth();
		System.out.println(earth);
		
		
		
		
		
		
		
		
/*		MoonDTO moonDTO = dao.getMoon(1);
		System.out.println(moonDTO);
*/	}

}

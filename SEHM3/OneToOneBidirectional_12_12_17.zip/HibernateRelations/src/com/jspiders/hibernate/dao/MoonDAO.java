package com.jspiders.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.jspiders.hibernate.dto.MoonDTO;
import com.jspiders.hibernate.util.HibernateUtil;

public class MoonDAO {

	public void saveMoon(MoonDTO dto) {
		Session session = null;
		Transaction transaction = null;
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			transaction = session.beginTransaction();
			session.save(dto);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
	}
	
	public MoonDTO getMoon(int primaryKey) {
		Session session = null;
		Transaction transaction = null;
		MoonDTO dto = null;
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			dto = session.get(MoonDTO.class, new Integer(primaryKey));
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
		return dto;
	}
}

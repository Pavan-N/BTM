package com.jspiders.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.jspiders.hibernate.dto.UFODTO;
import com.jspiders.hibernate.util.HibernateUtil;

public class UFODAO {

	public void saveUFO(UFODTO dto) {
		// Component 1
		SessionFactory factory = HibernateUtil.getSessionFactory();

		// Component 3
		Session session = factory.openSession();

		// Sub-component 1 of session
		Transaction tx = session.beginTransaction();

		session.save(dto);

		tx.commit();

		session.close();

		factory.close();
	}

	public UFODTO getUFO(int primaryKey) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		UFODTO dto = session.get(UFODTO.class, primaryKey);
		return dto;
	}

	public void updateUFO(int primaryKey) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = null;
		Transaction transaction = null;
		try {
			session = factory.openSession();
			transaction = session.beginTransaction();
			UFODTO ufodto = session.get(UFODTO.class, new Integer(primaryKey));
			ufodto.setShape("square");
			ufodto.setColour("someColour");
			session.update(ufodto);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
	
	
	
	
	
	

}

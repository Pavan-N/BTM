package com.jspiders.hibernate.tester;

import com.jspiders.hibernate.dao.UFODAO;
import com.jspiders.hibernate.dto.UFODTO;

public class AppTester {

	public static void main(String[] args) {
		/*UFODTO dto = new UFODTO();
		dto.setUfoId(1);
		dto.setShape("cylinder");
		dto.setSpeed(1000.798);
		dto.setColour("black and red");
		System.out.println(dto);*/
		
		UFODAO dao = new UFODAO();
		//dao.saveUFO(dto);
		//dao.updateUFO(1);
		
		
		UFODTO dto = dao.getUFO(1);
		System.out.println("shape:" + dto.getShape());
		System.out.println("speed: " + dto.getSpeed());
		
	}

}

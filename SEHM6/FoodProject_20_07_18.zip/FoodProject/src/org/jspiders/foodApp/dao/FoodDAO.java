package org.jspiders.foodApp.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.jspiders.foodApp.dto.FoodDTO;

import com.jspiders.hibernate.util.HibernateUtil;

public class FoodDAO {

	private SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
	
	public void saveFood(FoodDTO foodDTO) {
		Session session = sessionFactory.openSession();
		
		//Sub-Component 1
		Transaction transaction = session.beginTransaction();
		
		session.save(foodDTO);
		
		transaction.commit();
		
		session.close();
	}
	
	public FoodDTO getFoodById(int primaryKey) {
		Session session = sessionFactory.openSession();
		
		
		FoodDTO foodDTO = session.get(FoodDTO.class, new Integer(primaryKey));
		
		session.close();
		
		return foodDTO;
	}
	
	public FoodDTO UpdateFoodPriceById(int primaryKey, double price) {
		Session session = null;
		Transaction transaction = null;
		FoodDTO foodDTO = null;
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			foodDTO = session.load(FoodDTO.class, new Integer(primaryKey));
			if (foodDTO != null) {
				foodDTO.setPrice(price);
				session.update(foodDTO);
			}
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
		} finally {
			if (session != null)
				session.close();
		}
		return foodDTO;
	}
	
	
	
	
	
	
	
}

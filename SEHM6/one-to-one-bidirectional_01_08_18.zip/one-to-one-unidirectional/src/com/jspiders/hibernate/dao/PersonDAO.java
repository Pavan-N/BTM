package com.jspiders.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.jspiders.hibernate.dto.PersonDTO;
import com.jspiders.hibernate.util.HibernateUtil;

public class PersonDAO {

private SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
	
	public Integer savePerson(PersonDTO personDTO) {
		Session session = null;
		Transaction transaction = null;
		Integer primaryKey = null;
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			primaryKey = (Integer) session.save(personDTO);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return primaryKey;
	}
}

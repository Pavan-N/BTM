package org.jspiders.foodApp.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.jspiders.foodApp.dto.FoodDTO;

public class FoodDAO {

	public void saveFood(FoodDTO foodDTO) {
		//Component 1
		Configuration cfg = new Configuration();
		cfg.configure();
		
		//Component 2
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		
		//Component 3
		Session session = sessionFactory.openSession();
		
		//Sub-Component 1
		Transaction transaction = session.beginTransaction();
		
		session.save(foodDTO);
		
		transaction.commit();
		
		session.close();
	}
}

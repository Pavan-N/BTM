package com.jspiders.hibernate.tester;

import com.jspiders.hibernate.dao.AadharDAO;
import com.jspiders.hibernate.dto.AadharDTO;
import com.jspiders.hibernate.dto.PersonDTO;

public class RelationTester {

	public static void main(String[] args) {
		PersonDTO personDTO = new PersonDTO();
		
		AadharDTO aadharDTO = new AadharDTO();
		
		personDTO.setName("Roopak");
		personDTO.setMobileNumber(456789);
		personDTO.setAge(24);
		
		aadharDTO.setAddress("Bihar");
		aadharDTO.setTagline("Aam Aadmi ka adhikar");
		
		//uni-directional relationship
		aadharDTO.setPerson(personDTO);
		
		AadharDAO aadharDAO = new AadharDAO();
		aadharDAO.saveAadhar(aadharDTO, personDTO);
		
	}

}

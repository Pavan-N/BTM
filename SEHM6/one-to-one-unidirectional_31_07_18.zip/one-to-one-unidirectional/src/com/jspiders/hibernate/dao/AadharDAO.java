package com.jspiders.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.jspiders.hibernate.dto.AadharDTO;
import com.jspiders.hibernate.dto.PersonDTO;
import com.jspiders.hibernate.util.HibernateUtil;

public class AadharDAO {

	private SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
	
	public Long saveAadhar(AadharDTO aadharDTO) {
		Session session = null;
		Transaction transaction = null;
		Long primaryKey = null;
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			primaryKey = (Long) session.save(aadharDTO);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return primaryKey;
	}
}

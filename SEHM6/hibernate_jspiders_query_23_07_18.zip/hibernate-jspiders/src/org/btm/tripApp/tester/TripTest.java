package org.btm.tripApp.tester;
import org.btm.tripApp.dto.TripDTO;
import org.btm.tripApp.dao.TripDAO;;
public class TripTest
{
	public static void main(String[] args) 
	{
		TripDTO tripDTO=new TripDTO();
		tripDTO.setDestination("Shimla");
		tripDTO.setExpenses(12000);
		tripDTO.setPinCode(342321);
		tripDTO.setTripId(1);
		TripDAO tripDAO=new TripDAO();
		tripDAO.saveTrip(tripDTO);
	}
}

package org.btm.tripApp.dao;
import org.btm.tripApp.dto.TripDTO;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.jspiders.hibernate.util.HibernateUtil;

public class TripDAO 
{
	private SessionFactory sessionfactory=HibernateUtil.getSessionFactory();
	public  void saveTrip(TripDTO tripDTo)
	{
		Session session=null;
		Transaction transaction=null;
		try
		{
			
			session = sessionfactory.openSession();
			transaction=session.beginTransaction();
			session.save(tripDTo);
			transaction.commit();
		}
		catch (HibernateException e1)
		{
			e1.printStackTrace();
			transaction.rollback();
		}
		finally
		{
			session.close();
		}
		
	}
}

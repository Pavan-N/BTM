package org.btm.tripApp.tester;
import org.btm.tripApp.dto.TripDTO;
import org.btm.tripApp.dao.TripDAO;;
public class TripTest
{
	public static void main(String[] args) 
	{
		/*TripDTO tripDTO=new TripDTO();
		tripDTO.setDestination("Bangkok");
		tripDTO.setExpenses(42000);
		tripDTO.setPinCode(342321);

		TripDAO tripDAO=new TripDAO();
		tripDAO.saveTrip(tripDTO);*/
		
		TripDAO tripDAO = new TripDAO();
		/*double expenses = tripDAO.fetchExpensesByDestination("Bangkok");
		System.out.println("Expenses for the trip would be: " + expenses);*/
		
		int noOfRowsUpdated = tripDAO.updateExpensesByDestination("GOA", 15000);
		System.out.println("No of rows affected: " + noOfRowsUpdated);
	}
}

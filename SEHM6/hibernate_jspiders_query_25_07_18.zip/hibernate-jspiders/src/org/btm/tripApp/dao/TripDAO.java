package org.btm.tripApp.dao;

import org.btm.tripApp.dto.TripDTO;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.jspiders.hibernate.util.HibernateUtil;

public class TripDAO {
	private SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

	public void saveTrip(TripDTO tripDTo) {
		Session session = null;
		Transaction transaction = null;
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			session.save(tripDTo);
			transaction.commit();
		} catch (HibernateException e1) {
			e1.printStackTrace();
			transaction.rollback();
		} finally {
			session.close();
		}

	}

	public double fetchExpensesByDestination(String destination) {
		String selectQuery = "SELECT trip.expenses FROM TripDTO trip "
				+ "WHERE trip.destination = '"+ destination +"'";
		double expenses = 0.0;
		try (Session session = sessionFactory.openSession()) {
			Query query = session.createQuery(selectQuery);
			expenses = (double) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return expenses;
	}
	
	public int updateExpensesByDestination(String destination, double expenses) {
		String updateQuery = "UPDATE TripDTO trip SET trip.expenses="+ expenses +" WHERE trip.destination = '"+ destination +"'";
		int noOfRowsAffected = 0;
		Transaction transaction = null;
		try (Session session = sessionFactory.openSession()) {
			transaction = session.beginTransaction();
			Query query = session.createQuery(updateQuery);
			noOfRowsAffected = query.executeUpdate();
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
		}
		return noOfRowsAffected;
	}
	
	
	
	
	
	
	
	
	
	

}

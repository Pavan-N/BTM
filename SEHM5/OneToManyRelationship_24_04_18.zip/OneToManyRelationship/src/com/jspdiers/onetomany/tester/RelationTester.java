package com.jspdiers.onetomany.tester;

import java.util.ArrayList;
import java.util.List;

import com.jspdiers.onetomany.dao.FruitDAO;
import com.jspdiers.onetomany.dto.Fruit;
import com.jspdiers.onetomany.dto.Tree;

public class RelationTester {

	public static void main(String[] args) {
		Tree tree = new Tree();
		tree.setName("Mango");
		tree.setHeight(5);
		tree.setAge(50);
		
		Fruit fruit = new Fruit();
		fruit.setType("Sweet");
		fruit.setWeight(0.250);
		fruit.setColor("Yellow");
		fruit.setTree(tree);
		
		Fruit fruit2 = new Fruit();
		fruit2.setType("Sweet");
		fruit2.setWeight(0.360);
		fruit2.setColor("Green");
		fruit2.setTree(tree);
		
		List<Fruit> fruitList = new ArrayList<>();
		fruitList.add(fruit);
		fruitList.add(fruit2);

		tree.setFruitList(fruitList);
		
		FruitDAO dao = new FruitDAO();
		//dao.saveFruit(fruit);
		//dao.saveFruit(fruit2);
		
		dao.saveFruits(fruitList);
	}

}

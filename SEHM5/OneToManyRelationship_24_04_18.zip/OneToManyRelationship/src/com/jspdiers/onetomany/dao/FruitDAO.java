package com.jspdiers.onetomany.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.jspdiders.hibernate.util.HibernateUtil;
import com.jspdiers.onetomany.dto.Fruit;

public class FruitDAO {
	private SessionFactory factory = HibernateUtil.getSessionFactory();
	
	public void saveFruit(Fruit fruit) {
		Session session = null;
		Transaction tx = null;
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.saveOrUpdate(fruit);
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			if (session != null)
				session.close();
		}
	}

	public void saveFruits(List<Fruit> fruitList) {
		Session session = null;
		Transaction tx = null;
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			for (Fruit fruit : fruitList) {
				session.persist(fruit);
			}
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			if (session != null)
				session.close();
		}
	}
}

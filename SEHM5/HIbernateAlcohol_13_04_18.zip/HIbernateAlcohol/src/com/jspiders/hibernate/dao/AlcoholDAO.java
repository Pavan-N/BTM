package com.jspiders.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.jspdiders.hibernate.util.HibernateUtil;
import com.jspiders.hibernate.dto.AlcohalDTO;

public class AlcoholDAO {
	private  SessionFactory factory=HibernateUtil.getSessionFactory();
	
	public void save(AlcohalDTO alchDto)
	{
		Session session=null;
		Transaction tx= null;
		try {
			session=factory.openSession();
			tx=session.beginTransaction();
			session.save(alchDto);
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		finally
		{
			if(session !=null)	
				session.close();
		}
		
		
	}
	

}

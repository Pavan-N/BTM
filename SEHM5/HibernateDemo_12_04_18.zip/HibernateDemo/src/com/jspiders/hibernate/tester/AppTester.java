package com.jspiders.hibernate.tester;

import com.jspiders.hibernate.dao.FoodDAO;
import com.jspiders.hibernate.dto.FoodDTO;

public class AppTester {

	public static void main(String[] args) {
		FoodDTO foodDTO = new FoodDTO();
		foodDTO.setName("Chapathi");
		foodDTO.setType("wheat");
		foodDTO.setQuantity(50);
		foodDTO.setPrice(10);
		
		System.out.println(foodDTO.getName() + "\t" + foodDTO.getPrice());
		
		FoodDAO dao = new FoodDAO();
		
		dao.saveFood(foodDTO);
		
		/*FoodDTO dtoFromDb = dao.getFood(1);
		
		System.out.println(dtoFromDb.getName() + "\t" + dtoFromDb.getQuantity());*/
		
		//dao.updateFoodTypeById(1, "masala");
	}
}

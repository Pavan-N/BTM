package com.jspiders.hibernate.apptester;

import java.util.List;

import com.jspiders.hibernate.dao.AlcoholDAO;
import com.jspiders.hibernate.dto.AlcohalDTO;

public class appTester {

	public static void main(String[] args) {
		/*AlcohalDTO dto=new AlcohalDTO();
		dto.setName("OMR");
		dto.setId(123);
		dto.setQuantity(180);
		dto.setPrice(130.0);
		AlcoholDAO dao=new AlcoholDAO();
		dao.save(dto);*/
		Object obj;
		
		AlcoholDAO dao = new AlcoholDAO();
		AlcohalDTO alcohalDTO = dao.getAlcoholByName("KF");
		System.out.println(alcohalDTO.getQuantity() + "\t" + alcohalDTO.getPrice());
		
		/*List<AlcohalDTO> alcoholList = dao.getAllAlcohol();
		
		for (AlcohalDTO alcohalDTO : alcoholList) {
			System.out.println(alcohalDTO.getName() + "\t" + alcohalDTO.getType());
		}*/
		
		/*String typeOfAlcohol = dao.getAlcoholTypeByName("KF");
		System.out.println(typeOfAlcohol);*/
		
		/*int rowsUpdated = dao.updatePriceByName(125, "KF");
		System.out.println(rowsUpdated);*/
		
		
	}

}

package com.jspiders.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.jspiders.web.dto.UserDTO;
import com.jspiders.web.service.RegisterService;

@Controller
@RequestMapping("/")
public class RegisterController {
	
	@Autowired
	private RegisterService service;
	
	@RequestMapping(value = "/register.do", method = RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute UserDTO dto) {
		boolean flag = service.registerUser(dto);
		if (flag) {
			return new ModelAndView("success.jsp", "user", dto);
		} else {
			return new ModelAndView("failure.jsp");
		}
	}
}

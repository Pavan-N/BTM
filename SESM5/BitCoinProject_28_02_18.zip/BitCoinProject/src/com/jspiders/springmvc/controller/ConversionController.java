package com.jspiders.springmvc.controller;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;

@Component
@RequestMapping("/")
public class ConversionController {

	@RequestMapping(value = "/convert.do")
	public String convertDollarToRupees() {
		System.out.println("Inside convertDollarToRupees()");
		return "convert.jsp";
	}
	
}

package com.jspiders.spring.bean;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class RemoteBean implements Serializable {
	@Value(value = "80")
	private double price;
	@Value(value = "grey")
	private String colour;

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public void switchChannels() {
		System.out.println("Changing the channels");
	}

	@Override
	public String toString() {
		return "RemoteBean [price=" + price + ", colour=" + colour + "]";
	}
	
}

package com.jspiders.spring.bean;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class TvBean implements Serializable {
	
	private String name;
	@Value(value = "colour")
	private String type;
	@Value(value = "24")
	private double size;
	
	private RemoteBean remote;

	@Autowired
	public TvBean(RemoteBean remote) {
		this.remote = remote;
	}

	public String getName() {
		return name;
	}

	@Value(value = "Sony")
	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getSize() {
		return size;
	}

	public void setSize(double size) {
		this.size = size;
	}

	public RemoteBean getRemote() {
		return remote;
	}

	@Autowired
	@Qualifier
	public void setRemote(RemoteBean remote) {
		this.remote = remote;
	}

	public void display() {
		remote.switchChannels();
		System.out.println("Watching tv..");
	}

	@Override
	public String toString() {
		return "TvBean [name=" + name + ", type=" + type + ", size=" + size
				+ ", remote=" + remote + "]";
	}
	
}

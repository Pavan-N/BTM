package com.jspiders.spring.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.spring.bean.TvBean;

public class AnnotationsTester {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
		
		TvBean tvBean = context.getBean(TvBean.class);
		tvBean.display();
		System.out.println(tvBean);
		System.out.println(tvBean.getRemote());
		
	}

}

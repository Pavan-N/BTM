package com.jspiders.mvc.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jspiders.mvc.dto.LoginDTO;

@Component
public class LoginDAO {

	@Autowired
	private SessionFactory factory;
	
	public boolean authenticateUser(LoginDTO dto) {
		boolean flag = false;
		Session session = null;
		String hql = "SELECT dto FROM LoginDTO dto WHERE dto.username=:usrnm and "
				+ "dto.password=:pwd";
		try {
			session = factory.openSession();
			Query query = session.createQuery(hql);
			query.setParameter("usrnm", dto.getUsername());
			query.setParameter("pwd", dto.getPassword());	
			LoginDTO loginDTO = (LoginDTO) query.uniqueResult();
			if(loginDTO != null) {
				flag = true;
			} 
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
		/*
		if (dto.getUsername().equals("Shishira") && dto.getPassword().equals("dinga")) {
			return true;
		}
		return false;*/
	}

}

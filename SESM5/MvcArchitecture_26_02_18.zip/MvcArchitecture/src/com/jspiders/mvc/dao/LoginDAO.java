package com.jspiders.mvc.dao;

import org.springframework.stereotype.Component;

import com.jspiders.mvc.dto.LoginDTO;

@Component
public class LoginDAO {

	public boolean authenticateUser(LoginDTO dto) {
		if (dto.getUsername().equals("Shishira") && dto.getPassword().equals("dinga")) {
			return true;
		}
		return false;
	}

}

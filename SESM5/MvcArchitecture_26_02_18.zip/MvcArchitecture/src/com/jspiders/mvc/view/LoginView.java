package com.jspiders.mvc.view;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.mvc.controller.LoginController;
import com.jspiders.mvc.dto.LoginDTO;

public class LoginView {

	public static void main(String[] args) {
		//Presentation Logic
		
		ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
		LoginController controller = context.getBean(LoginController.class);
		
		String username = null;
		String password = null;
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter username");
		username = scan.next();
		
		System.out.println("Enter password");
		password = scan.next();
		
		LoginDTO dto = new LoginDTO();
		dto.setUsername(username);
		dto.setPassword(password);
		
		String message = controller.validateUser(dto);
		System.out.println(message);
		
	}
}

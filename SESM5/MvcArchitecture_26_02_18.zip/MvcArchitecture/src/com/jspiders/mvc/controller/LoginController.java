package com.jspiders.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jspiders.mvc.dto.LoginDTO;
import com.jspiders.mvc.service.LoginService;

@Component
public class LoginController {

	@Autowired
	private LoginService service;
	
	public String validateUser(LoginDTO dto) {
		boolean flag = service.validateUser(dto);
		
		if (flag) {
			return "Valid User. Display Home page.";
		}
		else {
			return "InValid Username or Password. Return to login page.";
		}
	}
}

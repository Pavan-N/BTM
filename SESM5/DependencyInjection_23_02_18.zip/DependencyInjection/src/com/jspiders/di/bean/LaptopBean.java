package com.jspiders.di.bean;

import java.io.Serializable;

public class LaptopBean implements Serializable {

	private String model;
	private double price;
	private OsBean os;

	public LaptopBean() {
		System.out.println(this.getClass().getSimpleName() + " created.");
	}

	public LaptopBean(OsBean os) {
		System.out.println(this.getClass().getSimpleName() + " created.");
		this.os = os;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public OsBean getOs() {
		return os;
	}

	public void setOs(OsBean os) {
		this.os = os;
	}

	public void performTask() {
		os.operate();
		System.out.println("Performing some task...");
	}
}

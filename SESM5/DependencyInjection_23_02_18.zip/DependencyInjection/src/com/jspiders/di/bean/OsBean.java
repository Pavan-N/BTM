package com.jspiders.di.bean;

public class OsBean {

	private String name;
	private double version;
	
	public OsBean() {
		System.out.println(this.getClass().getSimpleName() + " created.");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getVersion() {
		return version;
	}

	public void setVersion(double version) {
		this.version = version;
	}

	public void operate() {
		System.out.println("Operating and processing the system..");
	}

}

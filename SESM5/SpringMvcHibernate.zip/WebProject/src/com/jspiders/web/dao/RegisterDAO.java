package com.jspiders.web.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jspiders.web.dto.UserDTO;

@Repository
public class RegisterDAO {
	
	@Autowired
	private SessionFactory factory;

	public boolean saveUser(UserDTO dto) {
		boolean flag = false;
		Session session = null;
		Transaction tx = null;
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.save(dto);
			tx.commit();
			flag = true;
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
			flag = false;
		}
		return flag;
	}

}

package com.jspiders.web.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jspiders.web.dao.RegisterDAO;
import com.jspiders.web.dto.UserDTO;

@Service
public class RegisterService {

	@Autowired
	private RegisterDAO dao;
	
	public boolean registerUser(UserDTO dto) {
		return dao.saveUser(dto);
	}
}

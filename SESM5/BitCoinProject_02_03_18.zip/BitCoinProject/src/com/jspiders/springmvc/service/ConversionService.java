package com.jspiders.springmvc.service;

import org.springframework.stereotype.Service;

@Service
public class ConversionService {

	/*public Double convertAmountToRs(String amountInDollars) {
		double amount = 0.0;
		double amount = Double.parseDouble(amountInDollars);
		amount = amount * 65;
		return amount;
	}*/
	
	
	public Double convertAmountToRs(double amountInDollars) {
		return amountInDollars * 65;
	}

}

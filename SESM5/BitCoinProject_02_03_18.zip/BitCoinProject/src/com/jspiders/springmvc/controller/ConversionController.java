package com.jspiders.springmvc.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.jspiders.springmvc.service.ConversionService;

@Controller
@RequestMapping("/")
public class ConversionController {
	
	@Autowired
	private ConversionService service;

	/*@RequestMapping(value = "/convert.do")
	public String convertDollarToRupees(HttpServletRequest req) {
		String amountInDollars = req.getParameter("amount");
		Double convertedAmountRs = service.convertAmountToRs(amountInDollars);
		System.out.println("Inside convertDollarToRupees()");
		req.setAttribute("rsAmount", convertedAmountRs);
		return "convert.jsp";
	}*/
	
	@RequestMapping(value = "/convert.do")
	public ModelAndView convertDollarToRupees(@RequestParam Double amount) {
		Double convertedAmountRs = service.convertAmountToRs(amount);
		return new ModelAndView("convert.jsp", "rsAmount", convertedAmountRs);
	}
	
}

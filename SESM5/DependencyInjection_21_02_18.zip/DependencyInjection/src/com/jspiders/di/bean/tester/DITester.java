package com.jspiders.di.bean.tester;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jspiders.di.bean.LaptopBean;

public class DITester {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
		
		LaptopBean laptopBean = context.getBean(LaptopBean.class);
		laptopBean.performTask();
		
	}

}

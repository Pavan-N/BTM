package com.jspiders.spring.tester;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.jspiders.spring.bean.FoodBean;

public class AppTester {

	public static void main(String[] args) {
		ApplicationContext container = new ClassPathXmlApplicationContext("context.xml");
		/*Resource resource = new ClassPathResource("context.xml");
		BeanFactory container = new XmlBeanFactory(resource);
		*/	
		FoodBean foodBean = container.getBean("food1", FoodBean.class);
		foodBean.setName("Burger");
		foodBean.setPrice(200);
		foodBean.setQuantity(100);
		System.out.println("Food Name: " + foodBean.getName());
		System.out.println("Quantity: " + foodBean.getQuantity());
		System.out.println("Food Price: " + foodBean.getPrice());
		foodBean.provideEnergy();

		System.out.println("--------------------------------------------------");
		FoodBean foodBean1 = container.getBean("food1", FoodBean.class);
		System.out.println("Food Name: " + foodBean1.getName());
		System.out.println("Quantity: " + foodBean1.getQuantity());
		System.out.println("Food Price: " + foodBean1.getPrice());
		foodBean1.provideEnergy();
	}

}

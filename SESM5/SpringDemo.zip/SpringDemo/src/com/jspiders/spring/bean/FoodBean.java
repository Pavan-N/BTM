package com.jspiders.spring.bean;

import java.io.Serializable;

public class FoodBean implements Serializable {
	
	private int price;
	private String name;
	private int quantity;
	
	public FoodBean(String name, int quantity) {
		this.name = name;
		this.quantity = quantity;
	}

	public FoodBean() {
	}
	
	public void provideEnergy() {
		System.out.println("providing energy..");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
}
